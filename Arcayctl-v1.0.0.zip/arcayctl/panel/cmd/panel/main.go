package main

import (
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"log"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/golang-jwt/jwt/v5"
	"github.com/joho/godotenv"
	"golang.org/x/crypto/bcrypt"
)

var (
	jwtSecret   []byte
	adminEmail  string
	adminHash   string
	fqdn        string
	version     = "1.0.0"
	mu          sync.RWMutex
	initialized bool
)

type Claims struct {
	Email string `json:"email"`
	jwt.RegisteredClaims
}

func main() {
	_ = godotenv.Load("/etc/arcayctl/panel.env")
	_ = godotenv.Load(".env")

	fqdn = getEnv("FQDN", "localhost")
	adminEmail = getEnv("ADMIN_EMAIL", "admin@localhost")
	port := getEnv("PANEL_PORT", "8081")

	// Generate or load JWT secret
	jwtSecret = []byte(getEnv("JWT_SECRET", generateSecret()))

	// Load or create admin password
	loadAdminCredentials()

	app := fiber.New(fiber.Config{
		AppName:      "Arcayctl Panel",
		ServerHeader: "Arcayctl",
	})

	app.Use(recover.New())
	app.Use(logger.New())
	app.Use(cors.New())

	// Public routes
	app.Get("/", serveDashboard)
	app.Get("/api/health", healthHandler)
	app.Get("/api/version", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{"version": version, "name": "Arcayctl"})
	})
	app.Post("/api/auth/login", loginHandler)
	app.Get("/api/auth/me", authMiddleware, meHandler)

	// Protected example routes
	api := app.Group("/api", authMiddleware)
	api.Get("/servers", listServersHandler)
	api.Get("/stats", statsHandler)

	log.Printf("Arcayctl Panel v%s starting on :%s (FQDN: %s)", version, port, fqdn)
	if err := app.Listen(":" + port); err != nil {
		log.Fatal(err)
	}
}

func getEnv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}

func generateSecret() string {
	b := make([]byte, 32)
	_, _ = rand.Read(b)
	return base64.URLEncoding.EncodeToString(b)
}

func loadAdminCredentials() {
	// Prefer hash already in env
	if h := os.Getenv("ADMIN_PASSWORD_HASH"); h != "" {
		adminHash = h
		initialized = true
		return
	}

	// First run: read plain password file created by installer
	passFile := "/etc/arcayctl/admin.pass"
	if data, err := os.ReadFile(passFile); err == nil {
		plain := strings.TrimSpace(string(data))
		if plain != "" {
			hash, err := bcrypt.GenerateFromPassword([]byte(plain), bcrypt.DefaultCost)
			if err == nil {
				adminHash = string(hash)
				initialized = true
				// Remove the plain password file for security
				_ = os.Remove(passFile)
				log.Println("Admin password hashed and temporary file removed")
				return
			}
		}
	}

	// Fallback default (should not happen in normal install)
	hash, _ := bcrypt.GenerateFromPassword([]byte("changeme123"), bcrypt.DefaultCost)
	adminHash = string(hash)
	adminEmail = "admin@localhost"
	initialized = true
	log.Println("WARNING: Using fallback admin credentials")
}

func healthHandler(c *fiber.Ctx) error {
	return c.JSON(fiber.Map{
		"status":  "ok",
		"version": version,
		"fqdn":    fqdn,
	})
}

func loginHandler(c *fiber.Ctx) error {
	type LoginRequest struct {
		Email    string `json:"email"`
		Password string `json:"password"`
	}
	var req LoginRequest
	if err := c.BodyParser(&req); err != nil {
		return c.Status(400).JSON(fiber.Map{"error": "Invalid request"})
	}

	mu.RLock()
	defer mu.RUnlock()

	if !strings.EqualFold(req.Email, adminEmail) {
		return c.Status(401).JSON(fiber.Map{"error": "Invalid email or password"})
	}
	if err := bcrypt.CompareHashAndPassword([]byte(adminHash), []byte(req.Password)); err != nil {
		return c.Status(401).JSON(fiber.Map{"error": "Invalid email or password"})
	}

	claims := Claims{
		Email: adminEmail,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(time.Now().Add(24 * time.Hour)),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}
	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	signed, err := token.SignedString(jwtSecret)
	if err != nil {
		return c.Status(500).JSON(fiber.Map{"error": "Could not create token"})
	}

	return c.JSON(fiber.Map{
		"token": signed,
		"user": fiber.Map{
			"email": adminEmail,
			"role":  "admin",
		},
	})
}

func authMiddleware(c *fiber.Ctx) error {
	auth := c.Get("Authorization")
	if auth == "" || !strings.HasPrefix(auth, "Bearer ") {
		return c.Status(401).JSON(fiber.Map{"error": "Unauthorized"})
	}
	tokenStr := strings.TrimPrefix(auth, "Bearer ")

	claims := &Claims{}
	token, err := jwt.ParseWithClaims(tokenStr, claims, func(t *jwt.Token) (interface{}, error) {
		return jwtSecret, nil
	})
	if err != nil || !token.Valid {
		return c.Status(401).JSON(fiber.Map{"error": "Invalid or expired token"})
	}

	c.Locals("email", claims.Email)
	return c.Next()
}

func meHandler(c *fiber.Ctx) error {
	return c.JSON(fiber.Map{
		"email": c.Locals("email"),
		"role":  "admin",
	})
}

func listServersHandler(c *fiber.Ctx) error {
	// Placeholder – real server list will come later
	return c.JSON(fiber.Map{
		"data": []fiber.Map{},
		"meta": fiber.Map{"total": 0},
	})
}

func statsHandler(c *fiber.Ctx) error {
	return c.JSON(fiber.Map{
		"servers": 0,
		"nodes":   1,
		"users":   1,
		"status":  "operational",
	})
}

func serveDashboard(c *fiber.Ctx) error {
	c.Set("Content-Type", "text/html; charset=utf-8")
	return c.SendString(dashboardHTML)
}

// ─────────────────────────────────────────────
// Embedded Glassmorphism Dashboard
// ─────────────────────────────────────────────
const dashboardHTML = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Arcayctl – Game Server Panel</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg: #0a0a0a;
      --surface: rgba(255,255,255,0.03);
      --surface-hover: rgba(255,255,255,0.06);
      --border: rgba(255,255,255,0.08);
      --primary: #e11d48;
      --primary-hover: #be123c;
      --primary-glow: rgba(225,29,72,0.35);
      --text: #fafafa;
      --text-secondary: #a1a1aa;
      --text-muted: #71717a;
      --radius: 16px;
      --blur: 16px;
    }
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      font-family: 'Inter', system-ui, sans-serif;
      background: var(--bg);
      color: var(--text);
      min-height: 100vh;
      background-image:
        radial-gradient(ellipse at 20% 20%, rgba(225,29,72,0.08) 0%, transparent 50%),
        radial-gradient(ellipse at 80% 80%, rgba(225,29,72,0.05) 0%, transparent 50%);
    }
    .glass {
      background: rgba(20,20,20,0.65);
      backdrop-filter: blur(var(--blur));
      -webkit-backdrop-filter: blur(var(--blur));
      border: 1px solid var(--border);
      border-radius: var(--radius);
    }
    /* Login */
    #login-view {
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 24px;
    }
    .login-card {
      width: 100%;
      max-width: 400px;
      padding: 40px;
    }
    .logo {
      width: 48px; height: 48px;
      background: var(--primary);
      border-radius: 12px;
      display: flex; align-items: center; justify-content: center;
      font-weight: 700; font-size: 20px; color: white;
      margin: 0 auto 24px;
      box-shadow: 0 0 24px var(--primary-glow);
    }
    h1 { text-align:center; font-size:24px; font-weight:600; margin-bottom:8px; }
    .subtitle { text-align:center; color:var(--text-secondary); font-size:14px; margin-bottom:32px; }
    label { display:block; font-size:13px; color:var(--text-secondary); margin-bottom:6px; }
    input {
      width:100%; padding:12px 14px; border-radius:10px;
      background: rgba(255,255,255,0.04); border:1px solid var(--border);
      color:var(--text); font-size:14px; outline:none; transition: border 0.2s;
    }
    input:focus { border-color: var(--primary); }
    .field { margin-bottom:18px; }
    .btn {
      width:100%; padding:13px; border:none; border-radius:10px;
      background: var(--primary); color:white; font-weight:600; font-size:14px;
      cursor:pointer; transition: all 0.2s;
    }
    .btn:hover { background: var(--primary-hover); box-shadow: 0 0 20px var(--primary-glow); }
    .btn:disabled { opacity:0.6; cursor:not-allowed; }
    .error { color:#ef4444; font-size:13px; margin-top:12px; text-align:center; display:none; }
    /* Dashboard */
    #dash-view { display:none; min-height:100vh; }
    header {
      height:64px; border-bottom:1px solid var(--border);
      display:flex; align-items:center; justify-content:space-between;
      padding:0 28px; position:sticky; top:0; z-index:50;
      background: rgba(10,10,10,0.8); backdrop-filter: blur(12px);
    }
    .nav-brand { display:flex; align-items:center; gap:12px; font-weight:600; font-size:17px; }
    .nav-brand .logo { width:32px; height:32px; font-size:14px; margin:0; }
    .nav-right { display:flex; align-items:center; gap:16px; }
    .user-chip {
      padding:6px 12px; border-radius:999px; font-size:13px;
      background: rgba(255,255,255,0.05); border:1px solid var(--border);
      color: var(--text-secondary);
    }
    .btn-sm {
      padding:8px 14px; border-radius:8px; border:1px solid var(--border);
      background: transparent; color:var(--text-secondary); font-size:13px; cursor:pointer;
    }
    .btn-sm:hover { background: var(--surface-hover); color:var(--text); }
    main { max-width:1200px; margin:0 auto; padding:40px 28px; }
    .hero { margin-bottom:40px; }
    .hero h2 { font-size:28px; font-weight:600; margin-bottom:8px; }
    .hero p { color:var(--text-secondary); font-size:15px; }
    .grid { display:grid; grid-template-columns: repeat(auto-fit, minmax(240px,1fr)); gap:20px; margin-bottom:40px; }
    .stat-card { padding:24px; }
    .stat-card .label { font-size:13px; color:var(--text-muted); margin-bottom:8px; }
    .stat-card .value { font-size:32px; font-weight:700; }
    .stat-card .hint { font-size:12px; color:var(--text-secondary); margin-top:6px; }
    .section-title { font-size:18px; font-weight:600; margin-bottom:16px; }
    .empty {
      padding:60px 24px; text-align:center; color:var(--text-secondary);
    }
    .empty h3 { color:var(--text); margin-bottom:8px; }
  </style>
</head>
<body>
  <!-- LOGIN -->
  <div id="login-view">
    <div class="glass login-card">
      <div class="logo">A</div>
      <h1>Arcayctl</h1>
      <p class="subtitle">Sign in to your game server panel</p>
      <form id="login-form">
        <div class="field">
          <label>Email</label>
          <input type="email" id="email" required placeholder="admin@example.com" autocomplete="username" />
        </div>
        <div class="field">
          <label>Password</label>
          <input type="password" id="password" required placeholder="••••••••" autocomplete="current-password" />
        </div>
        <button type="submit" class="btn" id="login-btn">Sign In</button>
        <div class="error" id="login-error"></div>
      </form>
    </div>
  </div>

  <!-- DASHBOARD -->
  <div id="dash-view">
    <header>
      <div class="nav-brand">
        <div class="logo">A</div>
        Arcayctl
      </div>
      <div class="nav-right">
        <span class="user-chip" id="user-email"></span>
        <button class="btn-sm" onclick="logout()">Sign Out</button>
      </div>
    </header>
    <main>
      <div class="hero">
        <h2>Welcome back</h2>
        <p>Your modern game server control panel is ready.</p>
      </div>
      <div class="grid">
        <div class="glass stat-card">
          <div class="label">Servers</div>
          <div class="value" id="stat-servers">0</div>
          <div class="hint">Active game servers</div>
        </div>
        <div class="glass stat-card">
          <div class="label">Nodes</div>
          <div class="value" id="stat-nodes">1</div>
          <div class="hint">Connected nodes</div>
        </div>
        <div class="glass stat-card">
          <div class="label">Users</div>
          <div class="value" id="stat-users">1</div>
          <div class="hint">Registered accounts</div>
        </div>
        <div class="glass stat-card">
          <div class="label">Status</div>
          <div class="value" style="font-size:20px;color:#22c55e">Operational</div>
          <div class="hint">All systems normal</div>
        </div>
      </div>
      <h3 class="section-title">Servers</h3>
      <div class="glass empty">
        <h3>No servers yet</h3>
        <p>Server creation, console, file manager and more will appear here in the next updates.</p>
      </div>
    </main>
  </div>

  <script>
    const tokenKey = 'arcayctl_token';

    function show(view) {
      document.getElementById('login-view').style.display = view === 'login' ? 'flex' : 'none';
      document.getElementById('dash-view').style.display = view === 'dash' ? 'block' : 'none';
    }

    async function api(path, opts = {}) {
      const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
      const t = localStorage.getItem(tokenKey);
      if (t) headers['Authorization'] = 'Bearer ' + t;
      const res = await fetch(path, { ...opts, headers });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || 'Request failed');
      return data;
    }

    document.getElementById('login-form').addEventListener('submit', async (e) => {
      e.preventDefault();
      const btn = document.getElementById('login-btn');
      const err = document.getElementById('login-error');
      btn.disabled = true;
      err.style.display = 'none';
      try {
        const data = await api('/api/auth/login', {
          method: 'POST',
          body: JSON.stringify({
            email: document.getElementById('email').value,
            password: document.getElementById('password').value
          })
        });
        localStorage.setItem(tokenKey, data.token);
        enterDashboard(data.user);
      } catch (ex) {
        err.textContent = ex.message;
        err.style.display = 'block';
      } finally {
        btn.disabled = false;
      }
    });

    function enterDashboard(user) {
      document.getElementById('user-email').textContent = user.email;
      show('dash');
      loadStats();
    }

    async function loadStats() {
      try {
        const s = await api('/api/stats');
        document.getElementById('stat-servers').textContent = s.servers;
        document.getElementById('stat-nodes').textContent = s.nodes;
        document.getElementById('stat-users').textContent = s.users;
      } catch (_) {}
    }

    function logout() {
      localStorage.removeItem(tokenKey);
      show('login');
    }

    // Auto login if token exists
    (async () => {
      const t = localStorage.getItem(tokenKey);
      if (!t) { show('login'); return; }
      try {
        const me = await api('/api/auth/me');
        enterDashboard(me);
      } catch {
        localStorage.removeItem(tokenKey);
        show('login');
      }
    })();
  </script>
</body>
</html>`
