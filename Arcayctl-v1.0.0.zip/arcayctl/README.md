# Arcayctl v1.0.0

**Modern • Glassmorphism • Professional Game Server Management Panel**

Arcayctl is a next-generation game server control panel for Ubuntu & Debian.

---

## Features (v1)

- **Professional interactive installer**
  - Asks for FQDN / domain
  - Admin email + password
  - Optional Let's Encrypt SSL
  - DNS verification against server IP
  - Automatic PostgreSQL + Redis + Nginx + Docker setup
  - Systemd service + auto-start
- **Working Panel**
  - Beautiful glassmorphism login + dashboard
  - Secure JWT authentication
  - Admin account created during install
  - Real health & stats endpoints
- **Ready for expansion**
  - Clean Go codebase
  - Theme-ready CSS variables (Red/Black default)
  - Daemon placeholder ready for Wings-style features

---

## Requirements

- Ubuntu 22.04 / 24.04 or Debian 12 / 13
- Root access
- A domain (FQDN) pointing to the VPS (recommended for SSL)

---

## Quick Install

### Method 1 – Clone & Install (recommended)

```bash
# On your Ubuntu/Debian VPS
sudo apt update && sudo apt install -y git
git clone https://github.com/LORDBRAR5/Arcayctl.git
cd Arcayctl
sudo bash install.sh
```

### Method 2 – One-liner (after you push the extracted files)

```bash
curl -sSL https://raw.githubusercontent.com/LORDBRAR5/Arcayctl/main/install.sh | sudo bash
```

> **Important**: The repository root must contain `install.sh` and the `panel/` folder.  
> Do **not** upload only the zip – extract it first so the structure is:

```
Arcayctl/
├── install.sh
├── panel/
│   ├── go.mod
│   └── cmd/panel/main.go
├── README.md
└── ...
```

---

## What the Installer Asks

1. **Domain / FQDN** (e.g. `panel.yourdomain.com`)
2. DNS check (warns if the domain does not point to the server)
3. **Admin email**
4. **Admin password** (min 8 characters, confirmed)
5. **Let's Encrypt SSL?** (y/N)

Then it automatically:

- Installs Docker, PostgreSQL, Redis, Nginx, Certbot, Go
- Creates database + user
- Builds the Panel binary
- Configures Nginx reverse proxy
- Optionally obtains SSL certificate
- Enables & starts the systemd service

---

## After Installation

Open your browser:

```
http://your-domain.com
# or https:// if you enabled SSL
```

Login with the admin email and password you entered.

Useful commands:

```bash
systemctl status arcayctl-panel
systemctl restart arcayctl-panel
journalctl -u arcayctl-panel -f
```

Configuration is stored in:

```
/etc/arcayctl/panel.env
/etc/arcayctl/daemon/
```

---

## Current Status

**v1.0.0** is a solid, working foundation:

| Feature                    | Status      |
|---------------------------|-------------|
| Installer (FQDN, admin, SSL, DNS) | Working |
| Glassmorphism UI + Login  | Working     |
| JWT Auth                  | Working     |
| Nginx + Systemd           | Working     |
| Server management         | Coming soon |
| File manager / Console    | Coming soon |
| Daemon (Wings equivalent) | Placeholder |
| Spiderman & extra themes  | Planned    |

---

## Updating the Repository Correctly

1. Extract the new zip on your computer
2. Make sure the root of the repo contains `install.sh` and `panel/`
3. Commit and push:

```bash
git add .
git commit -m "Arcayctl v1.0.0 – full installer + working panel"
git push
```

---

## License

MIT
