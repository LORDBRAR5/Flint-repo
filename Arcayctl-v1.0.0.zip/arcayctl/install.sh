#!/usr/bin/env bash
#
# Arcayctl v1 Installer
# Professional installer for Ubuntu 22.04/24.04 & Debian 12/13
#
# Usage:
#   curl -sSL https://raw.githubusercontent.com/LORDBRAR5/Arcayctl/main/install.sh | sudo bash
#   or: sudo bash install.sh
#

set -euo pipefail

# ─────────────────────────────────────────────
# Colors
# ─────────────────────────────────────────────
CRIMSON='\033[38;2;225;29;72m'
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'

# ─────────────────────────────────────────────
# Globals
# ─────────────────────────────────────────────
VERSION="1.0.0"
INSTALL_DIR="/opt/arcayctl"
CONFIG_DIR="/etc/arcayctl"
DATA_DIR="/var/lib/arcayctl"
LOG_FILE="/var/log/arcayctl-install.log"
PANEL_PORT=8081
DAEMON_PORT=8080

FQDN=""
ADMIN_EMAIL=""
ADMIN_PASSWORD=""
ENABLE_SSL="n"
DB_PASSWORD=""
ASSUME_YES=false

# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────
print_banner() {
    clear
    echo -e "${CRIMSON}"
    cat << 'EOF'
    ___                    __  __
   /   |  ______________ _/ /_/ /_
  / /| | / ___/ ___/ __ `/ __/ __ \
 / ___ |/ /  / /__/ /_/ / /_/ / / /
/_/  |_/_/   \___/\__,_/\__/_/ /_/
EOF
    echo -e "${NC}"
    echo -e "  ${BOLD}Arcayctl v${VERSION}${NC}  •  Modern Game Server Panel"
    echo -e "  ${DIM}Ubuntu 22.04/24.04  •  Debian 12/13${NC}"
    echo -e "  ${DIM}──────────────────────────────────────────────${NC}"
    echo
}

log()   { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $*" >> "$LOG_FILE"; }
info()  { echo -e "  ${CRIMSON}●${NC} $*"; log "INFO  $*"; }
ok()    { echo -e "  ${GREEN}✔${NC} $*"; log "OK    $*"; }
warn()  { echo -e "  ${YELLOW}!${NC} $*"; log "WARN  $*"; }
fail()  { echo -e "  ${RED}✖${NC} $*"; log "ERROR $*"; exit 1; }

require_root() {
    [[ $EUID -eq 0 ]] || fail "Please run as root (sudo bash install.sh)"
}

detect_os() {
    if [[ ! -f /etc/os-release ]]; then
        fail "Cannot detect OS"
    fi
    # shellcheck source=/dev/null
    source /etc/os-release
    OS_ID="${ID,,}"
    OS_VER="${VERSION_ID}"

    case "$OS_ID" in
        ubuntu)
            [[ "$OS_VER" == "22.04" || "$OS_VER" == "24.04" ]] || warn "Ubuntu $OS_VER – tested on 22.04 & 24.04"
            ;;
        debian)
            [[ "$OS_VER" == "12" || "$OS_VER" == "13" ]] || warn "Debian $OS_VER – tested on 12 & 13"
            ;;
        *)
            fail "Unsupported OS: $PRETTY_NAME. Only Ubuntu & Debian are supported."
            ;;
    esac
    ok "Detected: $PRETTY_NAME"
}

# ─────────────────────────────────────────────
# Collect configuration from user
# ─────────────────────────────────────────────
ask_config() {
    echo -e "  ${BOLD}Panel Configuration${NC}"
    echo -e "  ${DIM}──────────────────────────────────────────────${NC}"
    echo

    # FQDN
    while true; do
        read -rp "  Domain / FQDN (e.g. panel.example.com): " FQDN
        FQDN=$(echo "$FQDN" | tr '[:upper:]' '[:lower:]' | xargs)
        if [[ -z "$FQDN" ]]; then
            warn "FQDN cannot be empty"
            continue
        fi
        if [[ ! "$FQDN" =~ ^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$ ]]; then
            warn "Invalid domain format"
            continue
        fi
        break
    done

    # DNS check
    info "Checking DNS for $FQDN ..."
    local resolved
    resolved=$(dig +short A "$FQDN" 2>/dev/null | head -1 || true)
    local public_ip
    public_ip=$(curl -4 -s --max-time 5 ifconfig.me 2>/dev/null || curl -4 -s --max-time 5 icanhazip.com 2>/dev/null || echo "unknown")

    if [[ -n "$resolved" ]]; then
        ok "DNS resolves to: $resolved"
        if [[ "$resolved" == "$public_ip" ]]; then
            ok "DNS points to this server ($public_ip)"
        else
            warn "DNS ($resolved) does not match this server IP ($public_ip)"
            warn "SSL and access may fail until DNS is correct"
            read -rp "  Continue anyway? [y/N]: " cont
            [[ "${cont,,}" == "y" ]] || fail "Aborted – fix DNS first"
        fi
    else
        warn "Could not resolve $FQDN – make sure an A record points to this server"
        read -rp "  Continue anyway? [y/N]: " cont
        [[ "${cont,,}" == "y" ]] || fail "Aborted – fix DNS first"
    fi

    # Admin email
    while true; do
        read -rp "  Admin email: " ADMIN_EMAIL
        if [[ "$ADMIN_EMAIL" =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
            break
        fi
        warn "Invalid email address"
    done

    # Admin password
    while true; do
        read -rsp "  Admin password (min 8 characters): " ADMIN_PASSWORD
        echo
        if [[ ${#ADMIN_PASSWORD} -lt 8 ]]; then
            warn "Password must be at least 8 characters"
            continue
        fi
        read -rsp "  Confirm password: " confirm
        echo
        if [[ "$ADMIN_PASSWORD" != "$confirm" ]]; then
            warn "Passwords do not match"
            continue
        fi
        break
    done

    # SSL
    echo
    read -rp "  Enable Let's Encrypt SSL? (requires valid DNS) [y/N]: " ENABLE_SSL
    ENABLE_SSL="${ENABLE_SSL,,}"

    echo
    ok "Configuration collected"
}

# ─────────────────────────────────────────────
# Dependencies
# ─────────────────────────────────────────────
install_deps() {
    info "Updating packages..."
    apt-get update -qq

    info "Installing dependencies..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        curl wget git jq unzip tar dig dnsutils \
        ca-certificates gnupg lsb-release \
        software-properties-common apt-transport-https \
        ufw fail2ban nginx certbot python3-certbot-nginx \
        postgresql postgresql-contrib redis-server > /dev/null

    # Docker
    if ! command -v docker &>/dev/null; then
        info "Installing Docker..."
        curl -fsSL https://get.docker.com | sh > /dev/null
        systemctl enable --now docker
        ok "Docker installed"
    else
        ok "Docker already present"
    fi

    # Go (for building)
    if ! command -v go &>/dev/null; then
        info "Installing Go..."
        local go_ver="1.22.5"
        wget -q "https://go.dev/dl/go${go_ver}.linux-amd64.tar.gz" -O /tmp/go.tar.gz
        rm -rf /usr/local/go
        tar -C /usr/local -xzf /tmp/go.tar.gz
        ln -sf /usr/local/go/bin/go /usr/local/bin/go
        ok "Go installed"
    else
        ok "Go already present"
    fi

    systemctl enable --now postgresql redis-server nginx
    ok "Core services ready"
}

# ─────────────────────────────────────────────
# Database
# ─────────────────────────────────────────────
setup_database() {
    info "Setting up PostgreSQL..."
    DB_PASSWORD=$(openssl rand -base64 32 | tr -d '/+=' | head -c 32)

    sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='arcayctl'" | grep -q 1 || \
        sudo -u postgres psql -c "CREATE USER arcayctl WITH PASSWORD '${DB_PASSWORD}';" > /dev/null

    sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='arcayctl'" | grep -q 1 || \
        sudo -u postgres psql -c "CREATE DATABASE arcayctl OWNER arcayctl;" > /dev/null

    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE arcayctl TO arcayctl;" > /dev/null
    sudo -u postgres psql -c "ALTER USER arcayctl WITH PASSWORD '${DB_PASSWORD}';" > /dev/null

    ok "Database ready"
}

# ─────────────────────────────────────────────
# Write configuration files
# ─────────────────────────────────────────────
write_configs() {
    info "Writing configuration..."

    mkdir -p "$CONFIG_DIR" "$DATA_DIR" "$INSTALL_DIR" /var/log/arcayctl

    # Main env
    cat > "$CONFIG_DIR/panel.env" <<EOF
# Arcayctl Panel Configuration – generated $(date -Iseconds)
ARCAYCTL_VERSION=${VERSION}
FQDN=${FQDN}
ADMIN_EMAIL=${ADMIN_EMAIL}
ADMIN_PASSWORD_HASH=
DB_HOST=127.0.0.1
DB_PORT=5432
DB_NAME=arcayctl
DB_USER=arcayctl
DB_PASSWORD=${DB_PASSWORD}
PANEL_PORT=${PANEL_PORT}
REDIS_ADDR=127.0.0.1:6379
DATA_DIR=${DATA_DIR}
EOF
    chmod 600 "$CONFIG_DIR/panel.env"

    # Save plain admin password temporarily for first-run (will be hashed by panel)
    echo "$ADMIN_PASSWORD" > "$CONFIG_DIR/admin.pass"
    chmod 600 "$CONFIG_DIR/admin.pass"

    # Daemon config
    mkdir -p "$CONFIG_DIR/daemon"
    cat > "$CONFIG_DIR/daemon/config.yml" <<EOF
debug: false
uuid: $(cat /proc/sys/kernel/random/uuid 2>/dev/null || uuidgen)
token_id: ""
token: ""
api:
  host: 0.0.0.0
  port: ${DAEMON_PORT}
  ssl:
    enabled: false
system:
  data: ${DATA_DIR}/volumes
  sftp:
    bind_port: 2022
remote: "http://127.0.0.1:${PANEL_PORT}"
EOF

    ok "Configuration written to $CONFIG_DIR"
}

# ─────────────────────────────────────────────
# Build & install Panel binary
# ─────────────────────────────────────────────
install_panel_binary() {
    info "Building Arcayctl Panel..."

    # The source is expected to be in the same directory as install.sh
    local src_dir
    src_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

    if [[ ! -d "$src_dir/panel" ]]; then
        fail "Panel source not found. Make sure you extracted the full repository."
    fi

    mkdir -p "$INSTALL_DIR/panel"
    cp -a "$src_dir/panel/." "$INSTALL_DIR/panel/"

    cd "$INSTALL_DIR/panel"
    export PATH=$PATH:/usr/local/go/bin
    go mod tidy 2>/dev/null || true
    CGO_ENABLED=0 go build -ldflags="-s -w" -o arcayctl-panel ./cmd/panel/

    if [[ ! -f arcayctl-panel ]]; then
        fail "Failed to build panel binary"
    fi

    chown -R www-data:www-data "$INSTALL_DIR/panel" 2>/dev/null || true
    ok "Panel binary built"
}

# ─────────────────────────────────────────────
# Systemd + Nginx
# ─────────────────────────────────────────────
setup_systemd() {
    info "Creating systemd service..."

    cat > /etc/systemd/system/arcayctl-panel.service << EOF
[Unit]
Description=Arcayctl Panel
After=network.target postgresql.service redis-server.service
Wants=postgresql.service redis-server.service

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}/panel
EnvironmentFile=${CONFIG_DIR}/panel.env
ExecStart=${INSTALL_DIR}/panel/arcayctl-panel
Restart=on-failure
RestartSec=5
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    systemctl enable arcayctl-panel
    ok "Systemd service created & enabled"
}

setup_nginx() {
    info "Configuring Nginx..."

    cat > /etc/nginx/sites-available/arcayctl << EOF
server {
    listen 80;
    listen [::]:80;
    server_name ${FQDN};

    location / {
        proxy_pass http://127.0.0.1:${PANEL_PORT};
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 86400;
    }
}
EOF

    ln -sf /etc/nginx/sites-available/arcayctl /etc/nginx/sites-enabled/arcayctl
    rm -f /etc/nginx/sites-enabled/default 2>/dev/null || true

    nginx -t
    systemctl reload nginx
    ok "Nginx configured for $FQDN"
}

setup_ssl() {
    if [[ "$ENABLE_SSL" != "y" ]]; then
        return
    fi

    info "Requesting Let's Encrypt certificate..."
    if certbot --nginx -d "$FQDN" --non-interactive --agree-tos -m "$ADMIN_EMAIL" --redirect; then
        ok "SSL certificate installed"
    else
        warn "Let's Encrypt failed – panel is still available on HTTP"
        warn "You can retry later with: certbot --nginx -d $FQDN"
    fi
}

start_services() {
    info "Starting Arcayctl Panel..."
    systemctl restart arcayctl-panel
    sleep 2

    if systemctl is-active --quiet arcayctl-panel; then
        ok "Panel is running"
    else
        warn "Panel service failed to start – check: journalctl -u arcayctl-panel -n 50"
    fi
}

# ─────────────────────────────────────────────
# Final summary
# ─────────────────────────────────────────────
print_summary() {
    echo
    echo -e "  ${GREEN}════════════════════════════════════════════${NC}"
    echo -e "  ${BOLD}Arcayctl v${VERSION} installed successfully!${NC}"
    echo -e "  ${GREEN}════════════════════════════════════════════${NC}"
    echo
    echo -e "  Panel URL   :  ${CRIMSON}http${ENABLE_SSL:+s}://${FQDN}${NC}"
    echo -e "  Admin Email :  ${ADMIN_EMAIL}"
    echo -e "  Admin Pass  :  (the one you entered)"
    echo
    echo -e "  Config dir  :  ${CONFIG_DIR}"
    echo -e "  Install dir :  ${INSTALL_DIR}"
    echo -e "  Logs        :  journalctl -u arcayctl-panel -f"
    echo
    echo -e "  ${DIM}Useful commands:${NC}"
    echo -e "    systemctl status arcayctl-panel"
    echo -e "    systemctl restart arcayctl-panel"
    echo -e "    journalctl -u arcayctl-panel -n 100"
    echo
    if [[ "$ENABLE_SSL" != "y" ]]; then
        echo -e "  ${YELLOW}SSL was not enabled. You can add it later:${NC}"
        echo -e "    certbot --nginx -d ${FQDN}"
        echo
    fi
    echo -e "  ${DIM}Thank you for using Arcayctl${NC}"
    echo
}

# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────
main() {
    mkdir -p /var/log
    touch "$LOG_FILE"

    require_root
    print_banner
    detect_os
    ask_config
    install_deps
    setup_database
    write_configs
    install_panel_binary
    setup_systemd
    setup_nginx
    setup_ssl
    start_services
    print_summary
}

main "$@"
