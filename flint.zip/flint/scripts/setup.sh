#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────
# Flint — one-shot production setup
# Run from the project root: bash scripts/setup.sh
# ─────────────────────────────────────────────────────────────
set -e

echo ""
echo "  ⚙  Flint setup"
echo "  ───────────────────────────────"

# 1. Node check
if ! command -v node &> /dev/null; then
  echo "  Node.js not found. Installing Node 20 via NodeSource…"
  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
  sudo apt-get install -y nodejs
fi
echo "  ✓ Node $(node -v)"

# 2. .env bootstrap
if [ ! -f .env ]; then
  cp .env.example .env
  SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('base64'))")
  # portable sed (works on both GNU and BSD sed)
  sed -i.bak "s|^NEXTAUTH_SECRET=.*|NEXTAUTH_SECRET=${SECRET}|" .env && rm -f .env.bak
  echo "  ✓ Created .env with a generated NEXTAUTH_SECRET"
  echo "    → Fill in DISCORD_/GOOGLE_ client credentials and SMTP_ settings before going live."
else
  echo "  ✓ .env already exists, leaving it as-is"
fi

mkdir -p data/uploads

# 3. Install deps
echo "  Installing dependencies…"
npm install --no-fund --no-audit

# 4. Database
echo "  Setting up database…"
npx prisma generate
npx prisma db push
npm run db:seed

# 5. Build
echo "  Building production bundle…"
npm run build

echo ""
echo "  ───────────────────────────────"
echo "  ✓ Flint is ready."
echo ""
echo "  Next steps:"
echo "   1. Edit .env — add Discord/Google OAuth credentials and SMTP settings."
echo "   2. Edit config/site.config.ts — links, domains, categories."
echo "   3. Set BOOTSTRAP_ADMIN_EMAIL in .env to your email, then sign in once — you'll become ADMIN automatically."
echo "   4. Start the app:"
echo "        npm start                     # runs on :3000"
echo "      or with pm2 for a persistent process:"
echo "        npm i -g pm2 && pm2 start npm --name flint -- start"
echo "   5. Point cloudflared (or your reverse proxy) at localhost:3000."
echo ""
