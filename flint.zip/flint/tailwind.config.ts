import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        ink: {
          DEFAULT: "#0A0A0C",
          soft: "#131316",
          raised: "#1B1B1F",
        },
        paper: {
          DEFAULT: "#F6F5F1",
          dim: "#C9C8C2",
        },
        ring: {
          DEFAULT: "#8B7CFF",
          dim: "#6C5CE0",
          glow: "#B4A9FF",
        },
        ember: {
          DEFAULT: "#FF6B4A",
          dim: "#D9502F",
        },
      },
      fontFamily: {
        display: ["var(--font-space-grotesk)", "system-ui", "sans-serif"],
        body: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
      backgroundImage: {
        "ring-glow":
          "radial-gradient(ellipse 60% 50% at 50% 0%, rgba(139,124,255,0.25), transparent 70%)",
        "ember-glow":
          "radial-gradient(ellipse 50% 40% at 100% 100%, rgba(255,107,74,0.18), transparent 70%)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
    },
  },
  plugins: [],
};

export default config;
