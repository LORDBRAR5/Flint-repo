import Link from "next/link";
import { siteConfig } from "@config/site.config";
import { Logo } from "@/components/logo";

export function Footer() {
  return (
    <footer className="border-t border-white/[0.06] mt-24">
      <div className="container-flint py-14 grid grid-cols-2 md:grid-cols-4 gap-10">
        <div className="col-span-2 md:col-span-1">
          <Logo />
          <p className="text-sm text-paper-dim mt-3 max-w-xs">{siteConfig.description}</p>
        </div>
        <div>
          <h4 className="text-sm font-medium mb-3">Browse</h4>
          <ul className="space-y-2 text-sm text-paper-dim">
            {siteConfig.categories.map((c) => (
              <li key={c.slug}>
                <Link href={`/browse/${c.slug}`} className="hover:text-paper transition-colors">
                  {c.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-medium mb-3">Community</h4>
          <ul className="space-y-2 text-sm text-paper-dim">
            <li><a href={siteConfig.links.discord} className="hover:text-paper transition-colors" target="_blank" rel="noreferrer">Discord</a></li>
            <li><a href={siteConfig.links.youtube} className="hover:text-paper transition-colors" target="_blank" rel="noreferrer">YouTube</a></li>
            <li><a href={siteConfig.links.instagram} className="hover:text-paper transition-colors" target="_blank" rel="noreferrer">Instagram</a></li>
            <li><a href={siteConfig.links.github} className="hover:text-paper transition-colors" target="_blank" rel="noreferrer">GitHub</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-sm font-medium mb-3">Flint</h4>
          <ul className="space-y-2 text-sm text-paper-dim">
            <li><Link href="/upload" className="hover:text-paper transition-colors">Submit a resource</Link></li>
            <li><Link href="/dashboard" className="hover:text-paper transition-colors">Your dashboard</Link></li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/[0.06] py-6 text-xs text-paper-dim/70 text-center">
        © {new Date().getFullYear()} {siteConfig.name}. All rights reserved.
      </div>
    </footer>
  );
}
