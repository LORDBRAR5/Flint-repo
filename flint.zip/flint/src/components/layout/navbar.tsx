"use client";

import Link from "next/link";
import { useState } from "react";
import { useSession, signOut } from "next-auth/react";
import { Search, Upload, Menu, X, LayoutDashboard, ShieldCheck } from "lucide-react";
import { Logo } from "@/components/logo";
import { siteConfig } from "@config/site.config";

export function Navbar() {
  const { data: session } = useSession();
  const [open, setOpen] = useState(false);
  const role = (session?.user as any)?.role;

  return (
    <header className="sticky top-0 z-40 glass border-x-0 border-t-0">
      <div className="container-flint flex items-center justify-between h-16">
        <div className="flex items-center gap-8">
          <Link href="/" aria-label="Flint home">
            <Logo />
          </Link>
          <nav className="hidden md:flex items-center gap-6 text-sm text-paper-dim">
            {siteConfig.categories.slice(0, 4).map((c) => (
              <Link key={c.slug} href={`/browse/${c.slug}`} className="hover:text-paper transition-colors">
                {c.label}
              </Link>
            ))}
            <Link href="/browse" className="hover:text-paper transition-colors">
              All resources
            </Link>
          </nav>
        </div>

        <div className="hidden md:flex items-center gap-3">
          <Link
            href="/browse"
            className="flex items-center gap-2 text-sm text-paper-dim glass rounded-full px-4 py-2 hover:text-paper transition-colors"
          >
            <Search size={15} /> Search resources
          </Link>
          {session?.user ? (
            <>
              <Link
                href="/upload"
                className="flex items-center gap-2 text-sm rounded-full px-4 py-2 bg-paper text-ink font-medium hover:bg-white transition-colors"
              >
                <Upload size={15} /> Submit
              </Link>
              {(role === "ADMIN" || role === "MODERATOR") && (
                <Link href="/admin" className="glass rounded-full p-2 text-paper-dim hover:text-paper" aria-label="Admin dashboard">
                  <ShieldCheck size={17} />
                </Link>
              )}
              <Link href="/dashboard" className="glass rounded-full p-2 text-paper-dim hover:text-paper" aria-label="Dashboard">
                <LayoutDashboard size={17} />
              </Link>
              <button
                onClick={() => signOut()}
                className="text-sm text-paper-dim hover:text-paper transition-colors"
              >
                Sign out
              </button>
            </>
          ) : (
            <Link
              href="/login"
              className="text-sm rounded-full px-5 py-2 bg-paper text-ink font-medium hover:bg-white transition-colors"
            >
              Sign in
            </Link>
          )}
        </div>

        <button className="md:hidden text-paper" onClick={() => setOpen((o) => !o)} aria-label="Toggle menu">
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {open && (
        <div className="md:hidden container-flint pb-5 flex flex-col gap-3 text-sm">
          {siteConfig.categories.map((c) => (
            <Link key={c.slug} href={`/browse/${c.slug}`} className="text-paper-dim" onClick={() => setOpen(false)}>
              {c.label}
            </Link>
          ))}
          <div className="h-px bg-white/10 my-1" />
          {session?.user ? (
            <>
              <Link href="/upload" onClick={() => setOpen(false)}>Submit a resource</Link>
              <Link href="/dashboard" onClick={() => setOpen(false)}>Dashboard</Link>
              {(role === "ADMIN" || role === "MODERATOR") && (
                <Link href="/admin" onClick={() => setOpen(false)}>Admin</Link>
              )}
              <button className="text-left text-paper-dim" onClick={() => signOut()}>Sign out</button>
            </>
          ) : (
            <Link href="/login" onClick={() => setOpen(false)}>Sign in</Link>
          )}
        </div>
      )}
    </header>
  );
}
