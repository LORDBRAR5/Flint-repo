"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import { timeAgo } from "@/lib/utils";

type UserRow = {
  id: string; name: string | null; username: string | null; email: string | null;
  role: string; banned: boolean; createdAt: string; _count: { resources: number };
};

export function UserModerationRow({ user }: { user: UserRow }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function doAction(action: string) {
    setBusy(true);
    let reason: string | undefined;
    if (action === "ban") reason = prompt("Reason for ban:") ?? undefined;
    const res = await fetch(`/api/admin/users/${user.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, reason }),
    });
    if (res.ok) { toast.success("Updated"); router.refresh(); }
    else toast.error("Action failed");
    setBusy(false);
  }

  return (
    <div className="p-4 flex flex-wrap items-center justify-between gap-3">
      <div>
        <div className="font-medium flex items-center gap-2">
          {user.name ?? user.username ?? "Unnamed"}
          {user.role !== "USER" && (
            <span className="text-xs rounded-full px-2 py-0.5 bg-ring/20 text-ring-glow">{user.role}</span>
          )}
          {user.banned && <span className="text-xs rounded-full px-2 py-0.5 bg-red-500/20 text-red-400">Banned</span>}
        </div>
        <div className="text-xs text-paper-dim mt-1">
          {user.email} · {user._count.resources} submissions · joined {timeAgo(user.createdAt)}
        </div>
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        {user.role === "USER" ? (
          <button disabled={busy} onClick={() => doAction("promote")} className="text-xs rounded-full px-3 py-1.5 glass">Make moderator</button>
        ) : (
          <button disabled={busy} onClick={() => doAction("demote")} className="text-xs rounded-full px-3 py-1.5 glass">Remove role</button>
        )}
        {user.banned ? (
          <button disabled={busy} onClick={() => doAction("unban")} className="text-xs rounded-full px-3 py-1.5 bg-emerald-500/15 text-emerald-400">Unban</button>
        ) : (
          <button disabled={busy} onClick={() => doAction("ban")} className="text-xs rounded-full px-3 py-1.5 bg-red-500/15 text-red-400">Ban</button>
        )}
      </div>
    </div>
  );
}
