"use client";

import { useState } from "react";
import toast from "react-hot-toast";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { StatusPill } from "@/components/status-pill";
import { timeAgo } from "@/lib/utils";

type Resource = {
  id: string; title: string; slug: string; status: string; featured: boolean; createdAt: string;
  category: { label: string }; author: { name: string | null; username: string | null };
};

export function ResourceModerationRow({ resource }: { resource: Resource }) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);

  async function doAction(action: string) {
    setBusy(true);
    let reason: string | undefined;
    if (action === "reject") {
      reason = prompt("Reason for rejection (shown to the author):") ?? undefined;
      if (!reason) { setBusy(false); return; }
    }
    const res = await fetch(`/api/admin/resources/${resource.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, reason }),
    });
    if (res.ok) {
      toast.success("Updated");
      router.refresh();
    } else {
      toast.error("Action failed");
    }
    setBusy(false);
  }

  async function doDelete() {
    if (!confirm(`Delete "${resource.title}" permanently?`)) return;
    setBusy(true);
    const res = await fetch(`/api/admin/resources/${resource.id}`, { method: "DELETE" });
    if (res.ok) {
      toast.success("Deleted");
      router.refresh();
    } else {
      toast.error("Delete failed");
    }
    setBusy(false);
  }

  return (
    <div className="p-4 flex flex-wrap items-center justify-between gap-3">
      <div className="min-w-0">
        <Link href={`/resource/${resource.slug}`} className="font-medium hover:text-ring-glow truncate block">
          {resource.title}
        </Link>
        <div className="text-xs text-paper-dim mt-1">
          {resource.category.label} · {resource.author.name ?? resource.author.username} · {timeAgo(resource.createdAt)}
        </div>
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        <StatusPill status={resource.status} />
        {resource.status === "PENDING_REVIEW" && (
          <>
            <button disabled={busy} onClick={() => doAction("approve")} className="text-xs rounded-full px-3 py-1.5 bg-emerald-500/15 text-emerald-400">Approve</button>
            <button disabled={busy} onClick={() => doAction("reject")} className="text-xs rounded-full px-3 py-1.5 bg-red-500/15 text-red-400">Reject</button>
          </>
        )}
        {resource.status === "PUBLISHED" && (
          <button disabled={busy} onClick={() => doAction(resource.featured ? "unfeature" : "feature")} className="text-xs rounded-full px-3 py-1.5 glass">
            {resource.featured ? "Unfeature" : "Feature"}
          </button>
        )}
        <button disabled={busy} onClick={doDelete} className="text-xs rounded-full px-3 py-1.5 glass text-red-400">Delete</button>
      </div>
    </div>
  );
}
