"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, PackageSearch, Users, BarChart3, ScrollText, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

const items = [
  { href: "/admin", label: "Overview", icon: LayoutDashboard, exact: true },
  { href: "/admin/resources", label: "Resources", icon: PackageSearch },
  { href: "/admin/users", label: "Users", icon: Users },
  { href: "/admin/analytics", label: "Analytics", icon: BarChart3 },
  { href: "/admin/logs", label: "Logs", icon: ScrollText },
  { href: "/admin/settings", label: "Settings", icon: Settings, adminOnly: true },
];

export function AdminSidebar({ role }: { role: string }) {
  const pathname = usePathname();
  return (
    <nav className="space-y-1 h-fit lg:sticky lg:top-24">
      <p className="text-xs uppercase tracking-wide text-paper-dim px-3 mb-2">Admin</p>
      {items
        .filter((i) => !i.adminOnly || role === "ADMIN")
        .map((item) => {
          const active = item.exact ? pathname === item.href : pathname.startsWith(item.href);
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm transition-colors",
                active ? "bg-white/[0.08] text-paper" : "text-paper-dim hover:text-paper hover:bg-white/[0.04]"
              )}
            >
              <Icon size={16} /> {item.label}
            </Link>
          );
        })}
    </nav>
  );
}
