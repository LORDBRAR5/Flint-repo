import { siteConfig } from "@config/site.config";

// Placeholder mark: a dark moon with a thin Saturn-style ring.
// Swap /public/icons/flint-mark.svg with the real logo when ready —
// every usage of the mark reads from siteConfig.brand.logoPlaceholder.
export function Logo({ size = 28 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2">
      <svg width={size} height={size} viewBox="0 0 40 40" fill="none" aria-hidden>
        <circle cx="20" cy="20" r="10" fill="#F6F5F1" />
        <circle cx="20" cy="20" r="10" fill="#0A0A0C" fillOpacity="0.55" />
        <ellipse
          cx="20"
          cy="20"
          rx="18"
          ry="6"
          stroke="url(#ring-gradient)"
          strokeWidth="1.4"
          transform="rotate(-18 20 20)"
        />
        <defs>
          <linearGradient id="ring-gradient" x1="2" y1="20" x2="38" y2="20">
            <stop stopColor="#8B7CFF" />
            <stop offset="1" stopColor="#FF6B4A" />
          </linearGradient>
        </defs>
      </svg>
      <span className="font-display font-semibold text-lg tracking-tight text-paper">
        {siteConfig.name}
      </span>
    </div>
  );
}
