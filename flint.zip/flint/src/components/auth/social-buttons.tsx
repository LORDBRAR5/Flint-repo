"use client";

import { signIn } from "next-auth/react";

export function SocialButtons() {
  return (
    <div className="space-y-2">
      <button
        onClick={() => signIn("discord", { callbackUrl: "/dashboard" })}
        className="w-full flex items-center justify-center gap-2 rounded-full glass py-3 text-sm font-medium hover:bg-white/[0.08] transition-colors"
      >
        Continue with Discord
      </button>
      <button
        onClick={() => signIn("google", { callbackUrl: "/dashboard" })}
        className="w-full flex items-center justify-center gap-2 rounded-full glass py-3 text-sm font-medium hover:bg-white/[0.08] transition-colors"
      >
        Continue with Google
      </button>
    </div>
  );
}
