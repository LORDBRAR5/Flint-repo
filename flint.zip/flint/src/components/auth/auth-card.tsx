import { Logo } from "@/components/logo";

export function AuthCard({
  title, subtitle, children,
}: { title: string; subtitle: string; children: React.ReactNode }) {
  return (
    <div className="min-h-[80vh] flex items-center justify-center bg-ring-glow">
      <div className="w-full max-w-sm glass-raised rounded-xl2 p-8">
        <div className="flex justify-center mb-6">
          <Logo size={32} />
        </div>
        <h1 className="text-xl font-semibold text-center">{title}</h1>
        <p className="text-sm text-paper-dim text-center mt-1.5 mb-6">{subtitle}</p>
        {children}
      </div>
    </div>
  );
}
