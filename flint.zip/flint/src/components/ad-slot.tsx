"use client";

import { siteConfig } from "@config/site.config";
import { cn } from "@/lib/utils";

// Neutral placeholder container ready for any ad network. When
// siteConfig.ads.enabled is true and a slot id is set, drop your
// network's script/ins tag in here — layout won't need to change.
export function AdSlot({ slot, className }: { slot: keyof typeof siteConfig.ads.slots; className?: string }) {
  const slotId = siteConfig.ads.slots[slot];
  if (!siteConfig.ads.enabled || !slotId) return null;

  return (
    <div
      className={cn("glass rounded-xl2 flex items-center justify-center text-xs text-paper-dim min-h-[90px]", className)}
      data-ad-slot={slotId}
      data-ad-provider={siteConfig.ads.provider}
    >
      Ad
    </div>
  );
}
