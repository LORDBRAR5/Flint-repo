"use client";

import { SessionProvider } from "next-auth/react";
import { Toaster } from "react-hot-toast";

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      {children}
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: "#1B1B1F",
            color: "#F6F5F1",
            border: "1px solid rgba(255,255,255,0.08)",
          },
        }}
      />
    </SessionProvider>
  );
}
