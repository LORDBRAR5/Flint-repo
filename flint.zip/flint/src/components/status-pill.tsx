import { cn } from "@/lib/utils";

const styles: Record<string, string> = {
  PUBLISHED: "bg-emerald-500/15 text-emerald-400",
  PENDING_REVIEW: "bg-amber-500/15 text-amber-400",
  REJECTED: "bg-red-500/15 text-red-400",
  ARCHIVED: "bg-white/10 text-paper-dim",
  DRAFT: "bg-white/10 text-paper-dim",
};

const labels: Record<string, string> = {
  PUBLISHED: "Published",
  PENDING_REVIEW: "In review",
  REJECTED: "Rejected",
  ARCHIVED: "Archived",
  DRAFT: "Draft",
};

export function StatusPill({ status }: { status: string }) {
  return (
    <span className={cn("text-xs font-medium px-3 py-1 rounded-full whitespace-nowrap", styles[status])}>
      {labels[status] ?? status}
    </span>
  );
}
