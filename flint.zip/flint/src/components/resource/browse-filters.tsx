"use client";

import Link from "next/link";
import { cn } from "@/lib/utils";

export function BrowseFilters({
  categories,
  activeCategory,
}: {
  categories: readonly { slug: string; label: string }[];
  activeCategory: string | null;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      <Link
        href="/browse"
        className={cn(
          "text-sm rounded-full px-4 py-2 transition-colors",
          !activeCategory ? "bg-paper text-ink font-medium" : "glass text-paper-dim hover:text-paper"
        )}
      >
        All
      </Link>
      {categories.map((c) => (
        <Link
          key={c.slug}
          href={`/browse/${c.slug}`}
          className={cn(
            "text-sm rounded-full px-4 py-2 transition-colors",
            activeCategory === c.slug ? "bg-paper text-ink font-medium" : "glass text-paper-dim hover:text-paper"
          )}
        >
          {c.label}
        </Link>
      ))}
    </div>
  );
}
