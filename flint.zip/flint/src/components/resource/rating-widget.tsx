"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import toast from "react-hot-toast";
import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function RatingWidget({ resourceId }: { resourceId: string }) {
  const { data: session } = useSession();
  const [stars, setStars] = useState(0);
  const [hover, setHover] = useState(0);
  const [sent, setSent] = useState(false);

  async function submit(value: number) {
    if (!session) {
      toast.error("Sign in to rate this resource.");
      return;
    }
    setStars(value);
    const res = await fetch(`/api/resources/${resourceId}/rating`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ stars: value }),
    });
    if (res.ok) {
      setSent(true);
      toast.success("Thanks for rating!");
    } else {
      toast.error("Couldn't save your rating.");
    }
  }

  return (
    <div className="glass rounded-xl2 p-5">
      <h3 className="font-medium mb-3">{sent ? "Your rating" : "Rate this resource"}</h3>
      <div className="flex gap-1">
        {[1, 2, 3, 4, 5].map((v) => (
          <button
            key={v}
            onMouseEnter={() => setHover(v)}
            onMouseLeave={() => setHover(0)}
            onClick={() => submit(v)}
            aria-label={`${v} stars`}
          >
            <Star
              size={24}
              className={cn(
                "transition-colors",
                (hover || stars) >= v ? "fill-ember text-ember" : "text-paper-dim"
              )}
            />
          </button>
        ))}
      </div>
    </div>
  );
}
