"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import toast from "react-hot-toast";
import { timeAgo } from "@/lib/utils";

type Comment = {
  id: string;
  body: string;
  createdAt: string;
  author: { name: string | null; username: string | null; image: string | null };
};

export function CommentSection({ resourceId }: { resourceId: string }) {
  const { data: session } = useSession();
  const [comments, setComments] = useState<Comment[]>([]);
  const [body, setBody] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/resources/${resourceId}/comments`)
      .then((r) => r.json())
      .then((d) => setComments(d.comments ?? []))
      .finally(() => setLoading(false));
  }, [resourceId]);

  async function submit() {
    if (!session) {
      toast.error("Sign in to comment.");
      return;
    }
    if (!body.trim()) return;
    const res = await fetch(`/api/resources/${resourceId}/comments`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ body }),
    });
    if (res.ok) {
      const data = await res.json();
      setComments((c) => [data.comment, ...c]);
      setBody("");
    } else {
      toast.error("Couldn't post comment.");
    }
  }

  return (
    <div>
      <h3 className="text-xl font-semibold mb-4">Discussion ({comments.length})</h3>
      <div className="glass rounded-xl2 p-4 mb-6">
        <textarea
          value={body}
          onChange={(e) => setBody(e.target.value)}
          placeholder={session ? "Share feedback or ask a question…" : "Sign in to join the discussion"}
          disabled={!session}
          rows={3}
          className="w-full bg-transparent outline-none resize-none placeholder:text-paper-dim/60 text-sm"
        />
        <div className="flex justify-end mt-2">
          <button
            onClick={submit}
            disabled={!session}
            className="text-sm rounded-full px-4 py-2 bg-paper text-ink font-medium disabled:opacity-50"
          >
            Post
          </button>
        </div>
      </div>

      {loading ? (
        <p className="text-sm text-paper-dim">Loading comments…</p>
      ) : comments.length === 0 ? (
        <p className="text-sm text-paper-dim">No comments yet — start the discussion.</p>
      ) : (
        <ul className="space-y-4">
          {comments.map((c) => (
            <li key={c.id} className="glass rounded-xl2 p-4">
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-medium">{c.author.name ?? c.author.username}</span>
                <span className="text-xs text-paper-dim">{timeAgo(c.createdAt)}</span>
              </div>
              <p className="text-sm text-paper/90">{c.body}</p>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
