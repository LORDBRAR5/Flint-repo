import Link from "next/link";
import { Star, Download } from "lucide-react";
import { formatNumber } from "@/lib/utils";

type ResourceCardProps = {
  resource: {
    id: string;
    slug: string;
    title: string;
    summary: string;
    downloadCount: number;
    category: { label: string; slug: string };
    author: { name: string | null; username: string | null };
    ratings: { stars: number }[];
  };
};

export function ResourceCard({ resource }: ResourceCardProps) {
  const avgRating =
    resource.ratings.length > 0
      ? resource.ratings.reduce((a, b) => a + b.stars, 0) / resource.ratings.length
      : null;

  return (
    <Link
      href={`/resource/${resource.slug}`}
      className="group glass hover:glass-raised rounded-xl2 p-5 flex flex-col gap-3 transition-colors"
    >
      <div className="flex items-center justify-between">
        <span className="text-xs uppercase tracking-wide text-ring font-medium">
          {resource.category.label}
        </span>
        {avgRating && (
          <span className="flex items-center gap-1 text-xs text-paper-dim">
            <Star size={12} className="fill-ember text-ember" /> {avgRating.toFixed(1)}
          </span>
        )}
      </div>
      <h3 className="font-display font-medium text-lg leading-snug group-hover:text-ring-glow transition-colors">
        {resource.title}
      </h3>
      <p className="text-sm text-paper-dim line-clamp-2">{resource.summary}</p>
      <div className="mt-auto flex items-center justify-between pt-2 text-xs text-paper-dim">
        <span>by {resource.author.name ?? resource.author.username ?? "Unknown"}</span>
        <span className="flex items-center gap-1">
          <Download size={12} /> {formatNumber(resource.downloadCount)}
        </span>
      </div>
    </Link>
  );
}
