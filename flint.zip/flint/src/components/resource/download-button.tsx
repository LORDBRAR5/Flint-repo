"use client";

import { useState } from "react";
import toast from "react-hot-toast";
import { Download } from "lucide-react";

export function DownloadButton({ resourceId, title }: { resourceId: string; title: string }) {
  const [loading, setLoading] = useState(false);

  async function handleDownload() {
    setLoading(true);
    try {
      const res = await fetch(`/api/resources/${resourceId}/download`, { method: "POST" });
      if (!res.ok) throw new Error();
      const data = await res.json();
      if (!data.file) {
        toast.error("No file attached to this resource yet.");
        return;
      }
      window.location.href = `/api/files/${data.file.id}`;
      toast.success(`Downloading ${title}`);
    } catch {
      toast.error("Couldn't start the download. Try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      onClick={handleDownload}
      disabled={loading}
      className="w-full flex items-center justify-center gap-2 rounded-full bg-paper text-ink font-medium py-3 hover:bg-white transition-colors disabled:opacity-60"
    >
      <Download size={16} /> {loading ? "Preparing…" : "Download"}
    </button>
  );
}
