"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import toast from "react-hot-toast";
import { AuthCard } from "@/components/auth/auth-card";

export default function VerifyPage() {
  const router = useRouter();
  const params = useSearchParams();
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);
  const email = params.get("email") || "";

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/auth/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, code }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "Verification failed");
        return;
      }
      toast.success("Email verified — you can sign in now.");
      router.push("/login");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthCard title="Verify your email" subtitle={`Enter the 6-digit code sent to ${email || "your email"}.`}>
      <form onSubmit={handleSubmit} className="space-y-3">
        <input
          required maxLength={6} placeholder="6-digit code" value={code}
          onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))}
          className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm text-center tracking-[0.5em] text-lg"
        />
        <button
          type="submit" disabled={loading || code.length !== 6}
          className="w-full rounded-full bg-paper text-ink font-medium py-3 hover:bg-white transition-colors disabled:opacity-60"
        >
          {loading ? "Verifying…" : "Verify"}
        </button>
      </form>
    </AuthCard>
  );
}
