import { siteConfig } from "@config/site.config";

// Serves /ads.txt for ad network verification. Add your network's
// line(s) here once approved, e.g.:
// google.com, pub-XXXXXXXXXXXXXXXX, DIRECT, f08c47fec0942fa0
export async function GET() {
  const lines = siteConfig.ads.enabled ? [] : [];
  return new Response(lines.join("\n"), { headers: { "Content-Type": "text/plain" } });
}
