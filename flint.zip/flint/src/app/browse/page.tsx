import { prisma } from "@/lib/prisma";
import { ResourceCard } from "@/components/resource/resource-card";
import { siteConfig } from "@config/site.config";
import { BrowseFilters } from "@/components/resource/browse-filters";

export default async function BrowseAllPage({ searchParams }: { searchParams: { q?: string; sort?: string } }) {
  const resources = await prisma.resource.findMany({
    where: {
      status: "PUBLISHED",
      ...(searchParams.q ? { title: { contains: searchParams.q } } : {}),
    },
    include: { category: true, author: true, ratings: true },
    orderBy: searchParams.sort === "popular" ? { downloadCount: "desc" } : { createdAt: "desc" },
    take: 60,
  });

  return (
    <div className="container-flint py-12">
      <h1 className="text-3xl font-semibold mb-2">All resources</h1>
      <p className="text-paper-dim mb-8">{resources.length} published right now.</p>
      <BrowseFilters categories={siteConfig.categories} activeCategory={null} />
      {resources.length === 0 ? (
        <div className="glass rounded-xl2 p-12 text-center text-paper-dim mt-6">No resources match yet.</div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mt-6">
          {resources.map((r) => (
            <ResourceCard key={r.id} resource={r as any} />
          ))}
        </div>
      )}
    </div>
  );
}
