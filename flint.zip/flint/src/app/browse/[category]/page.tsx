import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { ResourceCard } from "@/components/resource/resource-card";
import { siteConfig } from "@config/site.config";
import { BrowseFilters } from "@/components/resource/browse-filters";

export default async function BrowseCategoryPage({ params }: { params: { category: string } }) {
  const categoryMeta = siteConfig.categories.find((c) => c.slug === params.category);
  if (!categoryMeta) notFound();

  const resources = await prisma.resource.findMany({
    where: { status: "PUBLISHED", category: { slug: params.category } },
    include: { category: true, author: true, ratings: true },
    orderBy: { createdAt: "desc" },
    take: 60,
  });

  return (
    <div className="container-flint py-12">
      <h1 className="text-3xl font-semibold mb-2">{categoryMeta.label}</h1>
      <p className="text-paper-dim mb-8">{resources.length} resources in this category.</p>
      <BrowseFilters categories={siteConfig.categories} activeCategory={params.category} />
      {resources.length === 0 ? (
        <div className="glass rounded-xl2 p-12 text-center text-paper-dim mt-6">
          Nothing published in this category yet — check back soon.
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mt-6">
          {resources.map((r) => (
            <ResourceCard key={r.id} resource={r as any} />
          ))}
        </div>
      )}
    </div>
  );
}
