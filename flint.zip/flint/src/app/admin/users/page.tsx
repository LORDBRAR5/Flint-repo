import { prisma } from "@/lib/prisma";
import { UserModerationRow } from "@/components/admin/user-moderation-row";

export default async function AdminUsersPage() {
  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
    take: 200,
    include: { _count: { select: { resources: true } } },
  });

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-1">Users</h1>
      <p className="text-paper-dim text-sm mb-6">Manage roles and access.</p>
      <div className="glass rounded-xl2 divide-y divide-white/[0.06]">
        {users.map((u) => (
          <UserModerationRow key={u.id} user={u as any} />
        ))}
      </div>
    </div>
  );
}
