import { prisma } from "@/lib/prisma";
import { formatNumber } from "@/lib/utils";
import { AdminChart } from "@/components/admin/admin-chart";
import Link from "next/link";

export default async function AdminOverviewPage() {
  const [userCount, resourceCount, pendingCount, downloadCount, topResources, recentLogs] = await Promise.all([
    prisma.user.count(),
    prisma.resource.count({ where: { status: "PUBLISHED" } }),
    prisma.resource.count({ where: { status: "PENDING_REVIEW" } }),
    prisma.download.count(),
    prisma.resource.findMany({
      where: { status: "PUBLISHED" }, orderBy: { downloadCount: "desc" }, take: 5,
      select: { id: true, title: true, downloadCount: true, slug: true },
    }),
    prisma.adminLog.findMany({ orderBy: { createdAt: "desc" }, take: 6, include: { actor: true } }),
  ]);

  const since30d = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const recentDownloads = await prisma.download.findMany({ where: { createdAt: { gte: since30d } }, select: { createdAt: true } });
  const buckets: Record<string, number> = {};
  for (let i = 29; i >= 0; i--) {
    const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
    buckets[d.toISOString().slice(0, 10)] = 0;
  }
  for (const dl of recentDownloads) {
    const key = dl.createdAt.toISOString().slice(0, 10);
    if (key in buckets) buckets[key]++;
  }
  const chartData = Object.entries(buckets).map(([date, count]) => ({ date: date.slice(5), count }));

  const cards = [
    { label: "Total users", value: userCount },
    { label: "Published resources", value: resourceCount },
    { label: "Pending review", value: pendingCount, highlight: pendingCount > 0 },
    { label: "Total downloads", value: downloadCount },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold">Overview</h1>
        <p className="text-paper-dim text-sm mt-1">Snapshot of the whole platform.</p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c) => (
          <div key={c.label} className={`glass rounded-xl2 p-5 ${c.highlight ? "ring-1 ring-ember/50" : ""}`}>
            <div className="text-2xl font-display font-semibold">{formatNumber(c.value)}</div>
            <div className="text-xs text-paper-dim mt-1">{c.label}</div>
          </div>
        ))}
      </div>

      <div className="glass rounded-xl2 p-5">
        <h2 className="font-medium mb-4">Downloads — last 30 days</h2>
        <AdminChart data={chartData} />
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="glass rounded-xl2 p-5">
          <h2 className="font-medium mb-3">Top resources</h2>
          <ul className="space-y-2">
            {topResources.map((r) => (
              <li key={r.id} className="flex justify-between text-sm">
                <Link href={`/resource/${r.slug}`} className="text-paper-dim hover:text-paper truncate pr-3">{r.title}</Link>
                <span>{formatNumber(r.downloadCount)}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="glass rounded-xl2 p-5">
          <h2 className="font-medium mb-3">Recent admin activity</h2>
          <ul className="space-y-2 text-sm">
            {recentLogs.map((l) => (
              <li key={l.id} className="text-paper-dim">
                <span className="text-paper">{l.actor.name ?? l.actor.username}</span> — {l.action}
              </li>
            ))}
            {recentLogs.length === 0 && <li className="text-paper-dim">No activity yet.</li>}
          </ul>
        </div>
      </div>
    </div>
  );
}
