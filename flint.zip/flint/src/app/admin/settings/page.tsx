"use client";

import { useEffect, useState } from "react";
import toast from "react-hot-toast";

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<{ maintenanceMode?: boolean; allowSignups?: boolean; announcementBanner?: string }>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch("/api/admin/settings")
      .then((r) => r.json())
      .then((d) => setSettings(d.settings ?? {}))
      .finally(() => setLoading(false));
  }, []);

  async function save() {
    setSaving(true);
    const res = await fetch("/api/admin/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(settings),
    });
    if (res.ok) toast.success("Settings saved");
    else toast.error("Couldn't save settings");
    setSaving(false);
  }

  if (loading) return null;

  return (
    <div className="max-w-xl">
      <h1 className="text-2xl font-semibold mb-1">Settings</h1>
      <p className="text-paper-dim text-sm mb-6">
        Platform-wide toggles. Domains, links, and email identity live in{" "}
        <code className="text-xs bg-white/10 px-1.5 py-0.5 rounded">config/site.config.ts</code> instead.
      </p>

      <div className="glass rounded-xl2 p-5 space-y-5">
        <label className="flex items-center justify-between">
          <div>
            <div className="text-sm font-medium">Maintenance mode</div>
            <div className="text-xs text-paper-dim">Show a maintenance page to non-admins.</div>
          </div>
          <input
            type="checkbox"
            checked={!!settings.maintenanceMode}
            onChange={(e) => setSettings((s) => ({ ...s, maintenanceMode: e.target.checked }))}
            className="w-5 h-5 accent-ring"
          />
        </label>
        <label className="flex items-center justify-between">
          <div>
            <div className="text-sm font-medium">Allow new signups</div>
            <div className="text-xs text-paper-dim">Turn off to pause registrations.</div>
          </div>
          <input
            type="checkbox"
            checked={settings.allowSignups ?? true}
            onChange={(e) => setSettings((s) => ({ ...s, allowSignups: e.target.checked }))}
            className="w-5 h-5 accent-ring"
          />
        </label>
        <div>
          <div className="text-sm font-medium mb-1.5">Announcement banner</div>
          <input
            value={settings.announcementBanner ?? ""}
            onChange={(e) => setSettings((s) => ({ ...s, announcementBanner: e.target.value }))}
            placeholder="Leave blank to hide"
            className="w-full glass rounded-lg px-4 py-3 outline-none text-sm"
          />
        </div>
      </div>

      <button
        onClick={save}
        disabled={saving}
        className="mt-5 rounded-full bg-paper text-ink font-medium px-6 py-3 hover:bg-white transition-colors disabled:opacity-60"
      >
        {saving ? "Saving…" : "Save changes"}
      </button>
    </div>
  );
}
