import { prisma } from "@/lib/prisma";
import { ResourceModerationRow } from "@/components/admin/resource-moderation-row";

export default async function AdminResourcesPage() {
  const resources = await prisma.resource.findMany({
    orderBy: { createdAt: "desc" },
    include: { category: true, author: true },
    take: 100,
  });

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-1">Resources</h1>
      <p className="text-paper-dim text-sm mb-6">Approve, reject, feature, or remove submissions.</p>
      <div className="glass rounded-xl2 divide-y divide-white/[0.06]">
        {resources.map((r) => (
          <ResourceModerationRow key={r.id} resource={r as any} />
        ))}
        {resources.length === 0 && <div className="p-8 text-center text-paper-dim text-sm">No resources yet.</div>}
      </div>
    </div>
  );
}
