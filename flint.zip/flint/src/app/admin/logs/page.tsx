import { prisma } from "@/lib/prisma";
import { timeAgo } from "@/lib/utils";

export default async function AdminLogsPage() {
  const logs = await prisma.adminLog.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    include: { actor: true },
  });

  return (
    <div>
      <h1 className="text-2xl font-semibold mb-1">Audit logs</h1>
      <p className="text-paper-dim text-sm mb-6">Every admin action, most recent first.</p>
      <div className="glass rounded-xl2 divide-y divide-white/[0.06]">
        {logs.map((l) => (
          <div key={l.id} className="p-4 flex items-center justify-between gap-4 text-sm">
            <div>
              <span className="font-medium">{l.actor.name ?? l.actor.username}</span>
              <span className="text-paper-dim"> — {l.action}</span>
              {l.target && <span className="text-paper-dim/70 font-mono text-xs ml-2">#{l.target.slice(0, 8)}</span>}
            </div>
            <span className="text-xs text-paper-dim whitespace-nowrap">{timeAgo(l.createdAt)}</span>
          </div>
        ))}
        {logs.length === 0 && <div className="p-8 text-center text-paper-dim text-sm">No actions logged yet.</div>}
      </div>
    </div>
  );
}
