import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { AdminSidebar } from "@/components/admin/admin-sidebar";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await getServerSession(authOptions);
  const role = (session?.user as any)?.role;
  if (!session?.user || (role !== "ADMIN" && role !== "MODERATOR")) redirect("/");

  return (
    <div className="container-flint py-10 grid lg:grid-cols-[220px_1fr] gap-8">
      <AdminSidebar role={role} />
      <div>{children}</div>
    </div>
  );
}
