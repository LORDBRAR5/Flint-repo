import { prisma } from "@/lib/prisma";
import { AdminChart } from "@/components/admin/admin-chart";
import { formatNumber } from "@/lib/utils";

export default async function AdminAnalyticsPage() {
  const since30d = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  const [byCategory, recentDownloads, recentSignups, ratingCount] = await Promise.all([
    prisma.category.findMany({ include: { _count: { select: { resources: true } } } }),
    prisma.download.findMany({ where: { createdAt: { gte: since30d } }, select: { createdAt: true } }),
    prisma.user.findMany({ where: { createdAt: { gte: since30d } }, select: { createdAt: true } }),
    prisma.rating.count(),
  ]);

  function bucketize(rows: { createdAt: Date }[]) {
    const buckets: Record<string, number> = {};
    for (let i = 29; i >= 0; i--) {
      const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
      buckets[d.toISOString().slice(0, 10)] = 0;
    }
    for (const r of rows) {
      const key = r.createdAt.toISOString().slice(0, 10);
      if (key in buckets) buckets[key]++;
    }
    return Object.entries(buckets).map(([date, count]) => ({ date: date.slice(5), count }));
  }

  const maxCategoryCount = Math.max(1, ...byCategory.map((c) => c._count.resources));

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-semibold">Analytics</h1>
        <p className="text-paper-dim text-sm mt-1">Growth and engagement over the last 30 days.</p>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="glass rounded-xl2 p-5">
          <h2 className="font-medium mb-4">Downloads</h2>
          <AdminChart data={bucketize(recentDownloads)} />
        </div>
        <div className="glass rounded-xl2 p-5">
          <h2 className="font-medium mb-4">New users</h2>
          <AdminChart data={bucketize(recentSignups)} />
        </div>
      </div>

      <div className="glass rounded-xl2 p-5">
        <h2 className="font-medium mb-4">Resources by category</h2>
        <div className="space-y-3">
          {byCategory.map((c) => (
            <div key={c.id}>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-paper-dim">{c.label}</span>
                <span>{c._count.resources}</span>
              </div>
              <div className="h-1.5 rounded-full bg-white/[0.06]">
                <div
                  className="h-full rounded-full bg-ring"
                  style={{ width: `${(c._count.resources / maxCategoryCount) * 100}%` }}
                />
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="glass rounded-xl2 p-5 flex items-center justify-between">
        <span className="text-sm text-paper-dim">Total ratings submitted</span>
        <span className="text-xl font-display font-semibold">{formatNumber(ratingCount)}</span>
      </div>
    </div>
  );
}
