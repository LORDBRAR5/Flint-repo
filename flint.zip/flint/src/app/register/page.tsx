"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import toast from "react-hot-toast";
import { AuthCard } from "@/components/auth/auth-card";
import { SocialButtons } from "@/components/auth/social-buttons";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error ?? "Couldn't create account");
        return;
      }
      toast.success("Check your email for a verification code");
      router.push(`/verify?email=${encodeURIComponent(form.email)}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthCard title="Create your account" subtitle="Join Flint to submit resources and save your favorites.">
      <SocialButtons />
      <div className="flex items-center gap-3 my-5">
        <div className="h-px bg-white/10 flex-1" />
        <span className="text-xs text-paper-dim">or</span>
        <div className="h-px bg-white/10 flex-1" />
      </div>
      <form onSubmit={handleSubmit} className="space-y-3">
        <input
          required placeholder="Name" value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
          className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm"
        />
        <input
          type="email" required placeholder="Email" value={form.email}
          onChange={(e) => setForm({ ...form, email: e.target.value })}
          className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm"
        />
        <input
          type="password" required minLength={8} placeholder="Password (min. 8 characters)" value={form.password}
          onChange={(e) => setForm({ ...form, password: e.target.value })}
          className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm"
        />
        <button
          type="submit" disabled={loading}
          className="w-full rounded-full bg-paper text-ink font-medium py-3 hover:bg-white transition-colors disabled:opacity-60"
        >
          {loading ? "Creating account…" : "Create account"}
        </button>
      </form>
      <p className="text-sm text-paper-dim text-center mt-5">
        Already have an account? <Link href="/login" className="text-ring-glow hover:underline">Sign in</Link>
      </p>
    </AuthCard>
  );
}
