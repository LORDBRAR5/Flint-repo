import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/require-admin";

export async function GET() {
  const { ok } = await requireAdmin();
  if (!ok) return NextResponse.json({ error: "Unauthorized" }, { status: 403 });

  const since30d = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

  const [userCount, resourceCount, pendingCount, downloadCount, recentUsers, recentDownloads] = await Promise.all([
    prisma.user.count(),
    prisma.resource.count({ where: { status: "PUBLISHED" } }),
    prisma.resource.count({ where: { status: "PENDING_REVIEW" } }),
    prisma.download.count(),
    prisma.user.count({ where: { createdAt: { gte: since30d } } }),
    prisma.download.findMany({ where: { createdAt: { gte: since30d } }, select: { createdAt: true } }),
  ]);

  // bucket downloads by day for the last 30 days
  const buckets: Record<string, number> = {};
  for (let i = 29; i >= 0; i--) {
    const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
    buckets[d.toISOString().slice(0, 10)] = 0;
  }
  for (const dl of recentDownloads) {
    const key = dl.createdAt.toISOString().slice(0, 10);
    if (key in buckets) buckets[key]++;
  }

  const topResources = await prisma.resource.findMany({
    where: { status: "PUBLISHED" },
    orderBy: { downloadCount: "desc" },
    take: 5,
    select: { id: true, title: true, downloadCount: true, slug: true },
  });

  return NextResponse.json({
    userCount,
    resourceCount,
    pendingCount,
    downloadCount,
    recentUsers,
    downloadsByDay: Object.entries(buckets).map(([date, count]) => ({ date, count })),
    topResources,
  });
}
