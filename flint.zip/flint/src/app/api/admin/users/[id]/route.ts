import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/require-admin";
import { z } from "zod";

const schema = z.object({
  action: z.enum(["ban", "unban", "promote", "demote"]),
  reason: z.string().optional(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const { ok, session } = await requireAdmin();
  if (!ok) return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  if ((session!.user as any).role !== "ADMIN") {
    return NextResponse.json({ error: "Only admins can manage users" }, { status: 403 });
  }

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const dataMap: Record<string, any> = {
    ban: { banned: true, banReason: parsed.data.reason },
    unban: { banned: false, banReason: null },
    promote: { role: "MODERATOR" },
    demote: { role: "USER" },
  };

  const user = await prisma.user.update({ where: { id: params.id }, data: dataMap[parsed.data.action] });
  await logAdminAction((session!.user as any).id, `user.${parsed.data.action}`, params.id);

  return NextResponse.json({ user });
}
