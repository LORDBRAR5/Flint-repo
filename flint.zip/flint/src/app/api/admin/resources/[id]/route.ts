import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/require-admin";
import { z } from "zod";

const schema = z.object({
  action: z.enum(["approve", "reject", "archive", "feature", "unfeature"]),
  reason: z.string().optional(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const { ok, session } = await requireAdmin();
  if (!ok) return NextResponse.json({ error: "Unauthorized" }, { status: 403 });

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const statusMap: Record<string, any> = {
    approve: { status: "PUBLISHED" },
    reject: { status: "REJECTED", rejectReason: parsed.data.reason },
    archive: { status: "ARCHIVED" },
    feature: { featured: true },
    unfeature: { featured: false },
  };

  const resource = await prisma.resource.update({
    where: { id: params.id },
    data: statusMap[parsed.data.action],
  });

  await logAdminAction((session!.user as any).id, `resource.${parsed.data.action}`, params.id);

  return NextResponse.json({ resource });
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  const { ok, session } = await requireAdmin();
  if (!ok) return NextResponse.json({ error: "Unauthorized" }, { status: 403 });

  await prisma.resource.delete({ where: { id: params.id } });
  await logAdminAction((session!.user as any).id, "resource.delete", params.id);

  return NextResponse.json({ ok: true });
}
