import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin, logAdminAction } from "@/lib/require-admin";

export async function GET() {
  const { ok } = await requireAdmin();
  if (!ok) return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  const settings = await prisma.siteSetting.findMany();
  return NextResponse.json({
    settings: Object.fromEntries(settings.map((s) => [s.key, JSON.parse(s.value)])),
  });
}

export async function PUT(req: Request) {
  const { ok, session } = await requireAdmin();
  if (!ok) return NextResponse.json({ error: "Unauthorized" }, { status: 403 });
  if ((session!.user as any).role !== "ADMIN") {
    return NextResponse.json({ error: "Only admins can change settings" }, { status: 403 });
  }

  const body = await req.json();
  const entries = Object.entries(body) as [string, unknown][];

  await prisma.$transaction(
    entries.map(([key, value]) =>
      prisma.siteSetting.upsert({
        where: { key },
        update: { value: JSON.stringify(value) },
        create: { key, value: JSON.stringify(value) },
      })
    )
  );

  await logAdminAction((session!.user as any).id, "settings.update", undefined, body as Record<string, unknown>);

  return NextResponse.json({ ok: true });
}
