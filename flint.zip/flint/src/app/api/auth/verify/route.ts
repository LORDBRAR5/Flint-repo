import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const schema = z.object({
  email: z.string().email(),
  code: z.string().length(6),
});

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const { email, code } = parsed.data;
  const normalizedEmail = email.toLowerCase();

  const record = await prisma.verificationCode.findFirst({
    where: { email: normalizedEmail, code, purpose: "signup", usedAt: null, expiresAt: { gt: new Date() } },
    orderBy: { createdAt: "desc" },
  });

  if (!record) {
    return NextResponse.json({ error: "Invalid or expired code." }, { status: 400 });
  }

  await prisma.$transaction([
    prisma.verificationCode.update({ where: { id: record.id }, data: { usedAt: new Date() } }),
    prisma.user.update({ where: { email: normalizedEmail }, data: { emailVerified: new Date() } }),
  ]);

  return NextResponse.json({ ok: true });
}
