import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { generateCode } from "@/lib/utils";
import { sendMail, verificationCodeEmail } from "@/lib/mailer";

const schema = z.object({
  name: z.string().min(2).max(40),
  email: z.string().email(),
  password: z.string().min(8),
});

export async function POST(req: Request) {
  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Invalid input", details: parsed.error.flatten() }, { status: 400 });
  }
  const signupsSetting = await prisma.siteSetting.findUnique({ where: { key: "allowSignups" } });
  if (signupsSetting && JSON.parse(signupsSetting.value) === false) {
    return NextResponse.json({ error: "Signups are temporarily closed." }, { status: 403 });
  }

  const { name, email, password } = parsed.data;
  const normalizedEmail = email.toLowerCase();

  const existing = await prisma.user.findUnique({ where: { email: normalizedEmail } });
  if (existing) {
    return NextResponse.json({ error: "An account with that email already exists." }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(password, 12);
  const user = await prisma.user.create({
    data: { name, email: normalizedEmail, passwordHash },
  });

  const code = generateCode(6);
  await prisma.verificationCode.create({
    data: {
      userId: user.id,
      email: normalizedEmail,
      code,
      purpose: "signup",
      expiresAt: new Date(Date.now() + 15 * 60 * 1000),
    },
  });

  await sendMail(normalizedEmail, "Verify your Flint account", verificationCodeEmail(code));

  return NextResponse.json({ ok: true, email: normalizedEmail });
}
