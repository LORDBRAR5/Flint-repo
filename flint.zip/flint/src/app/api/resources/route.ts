import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import slugify from "slugify";
import { z } from "zod";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const category = searchParams.get("category");
  const q = searchParams.get("q");
  const sort = searchParams.get("sort") || "new";

  const resources = await prisma.resource.findMany({
    where: {
      status: "PUBLISHED",
      ...(category ? { category: { slug: category } } : {}),
      ...(q ? { title: { contains: q } } : {}),
    },
    include: {
      category: true,
      author: { select: { name: true, username: true, image: true } },
      ratings: true,
    },
    orderBy:
      sort === "popular" ? { downloadCount: "desc" } : sort === "top" ? { ratings: { _count: "desc" } } : { createdAt: "desc" },
    take: 60,
  });

  return NextResponse.json({ resources });
}

const createSchema = z.object({
  title: z.string().min(3).max(80),
  summary: z.string().min(10).max(200),
  description: z.string().min(20),
  categorySlug: z.string(),
  tags: z.array(z.string()).max(8).optional(),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid input", details: parsed.error.flatten() }, { status: 400 });

  const category = await prisma.category.findUnique({ where: { slug: parsed.data.categorySlug } });
  if (!category) return NextResponse.json({ error: "Unknown category" }, { status: 400 });

  const baseSlug = slugify(parsed.data.title, { lower: true, strict: true });
  let slug = baseSlug;
  let i = 1;
  while (await prisma.resource.findUnique({ where: { slug } })) {
    slug = `${baseSlug}-${i++}`;
  }

  const resource = await prisma.resource.create({
    data: {
      title: parsed.data.title,
      summary: parsed.data.summary,
      description: parsed.data.description,
      slug,
      categoryId: category.id,
      authorId: (session.user as any).id,
      status: "PENDING_REVIEW",
      tags: parsed.data.tags?.length
        ? {
            create: parsed.data.tags.map((name) => ({
              tag: { connectOrCreate: { where: { name }, create: { name } } },
            })),
          }
        : undefined,
    },
  });

  return NextResponse.json({ resource });
}
