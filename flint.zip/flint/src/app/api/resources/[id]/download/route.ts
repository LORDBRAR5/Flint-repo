import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  const resource = await prisma.resource.findUnique({
    where: { id: params.id },
    include: { files: true },
  });
  if (!resource || resource.status !== "PUBLISHED") {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  await prisma.$transaction([
    prisma.download.create({
      data: {
        resourceId: resource.id,
        userId: (session?.user as any)?.id ?? null,
        ip: req.headers.get("x-forwarded-for") ?? undefined,
      },
    }),
    prisma.resource.update({ where: { id: resource.id }, data: { downloadCount: { increment: 1 } } }),
  ]);

  const latestFile = resource.files.at(-1);
  return NextResponse.json({ file: latestFile ?? null });
}
