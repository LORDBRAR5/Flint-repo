import { NextResponse } from "next/server";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

const UPLOADS_DIR = process.env.UPLOADS_DIR || "./data/uploads";
const MAX_MB = Number(process.env.MAX_UPLOAD_MB || 200);

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const resource = await prisma.resource.findUnique({ where: { id: params.id } });
  if (!resource) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (resource.authorId !== (session.user as any).id && (session.user as any).role === "USER") {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const formData = await req.formData();
  const file = formData.get("file") as File | null;
  if (!file) return NextResponse.json({ error: "No file provided" }, { status: 400 });

  if (file.size > MAX_MB * 1024 * 1024) {
    return NextResponse.json({ error: `File exceeds ${MAX_MB}MB limit` }, { status: 413 });
  }

  const dir = path.join(UPLOADS_DIR, resource.id);
  await mkdir(dir, { recursive: true });
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const filePath = path.join(dir, `${Date.now()}-${safeName}`);
  const buffer = Buffer.from(await file.arrayBuffer());
  await writeFile(filePath, buffer);

  const record = await prisma.resourceFile.create({
    data: {
      resourceId: resource.id,
      filename: file.name,
      path: filePath,
      sizeBytes: file.size,
    },
  });

  return NextResponse.json({ file: record });
}
