import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const schema = z.object({ stars: z.number().min(1).max(5), review: z.string().max(500).optional() });

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const rating = await prisma.rating.upsert({
    where: { resourceId_userId: { resourceId: params.id, userId: (session.user as any).id } },
    update: { stars: parsed.data.stars, review: parsed.data.review },
    create: {
      resourceId: params.id,
      userId: (session.user as any).id,
      stars: parsed.data.stars,
      review: parsed.data.review,
    },
  });
  return NextResponse.json({ rating });
}
