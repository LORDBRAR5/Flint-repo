import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const comments = await prisma.comment.findMany({
    where: { resourceId: params.id },
    include: { author: { select: { name: true, username: true, image: true } } },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ comments });
}

const schema = z.object({ body: z.string().min(1).max(2000) });

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  const comment = await prisma.comment.create({
    data: { resourceId: params.id, authorId: (session.user as any).id, body: parsed.data.body },
    include: { author: { select: { name: true, username: true, image: true } } },
  });
  return NextResponse.json({ comment });
}
