import Link from "next/link";
import { ArrowRight, Blocks, Mountain, Server, LayoutTemplate, Bot, Code2 } from "lucide-react";
import { siteConfig } from "@config/site.config";
import { prisma } from "@/lib/prisma";
import { ResourceCard } from "@/components/resource/resource-card";
import { formatNumber } from "@/lib/utils";

const iconMap: Record<string, any> = { Blocks, Mountain, Server, LayoutTemplate, Bot, Code2 };

export default async function HomePage() {
  const [featured, recent, stats] = await Promise.all([
    prisma.resource.findMany({
      where: { status: "PUBLISHED", featured: true },
      include: { category: true, author: true, ratings: true },
      take: 3,
    }),
    prisma.resource.findMany({
      where: { status: "PUBLISHED" },
      include: { category: true, author: true, ratings: true },
      orderBy: { createdAt: "desc" },
      take: 8,
    }),
    prisma.$transaction([
      prisma.resource.count({ where: { status: "PUBLISHED" } }),
      prisma.user.count(),
      prisma.download.count(),
    ]),
  ]);

  const [resourceCount, userCount, downloadCount] = stats;

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-ring-glow">
        <div className="container-flint pt-20 pb-16 md:pt-28 md:pb-24">
          <div className="max-w-2xl">
            <p className="text-sm text-ring-glow font-medium tracking-tight text-ring">
              Free · community-built · always growing
            </p>
            <h1 className="mt-4 text-4xl md:text-6xl font-semibold leading-[1.05] tracking-tight">
              Everything you need to build your server.
            </h1>
            <p className="mt-5 text-lg text-paper-dim max-w-lg">
              {siteConfig.description}
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/browse"
                className="flex items-center gap-2 rounded-full bg-paper text-ink px-6 py-3 font-medium hover:bg-white transition-colors"
              >
                Browse resources <ArrowRight size={16} />
              </Link>
              <Link
                href="/upload"
                className="flex items-center gap-2 rounded-full glass px-6 py-3 font-medium hover:bg-white/[0.08] transition-colors"
              >
                Submit your work
              </Link>
            </div>
            <div className="mt-12 flex gap-10">
              <div>
                <div className="text-2xl font-display font-semibold">{formatNumber(resourceCount)}</div>
                <div className="text-xs text-paper-dim mt-1">Resources</div>
              </div>
              <div>
                <div className="text-2xl font-display font-semibold">{formatNumber(userCount)}</div>
                <div className="text-xs text-paper-dim mt-1">Builders</div>
              </div>
              <div>
                <div className="text-2xl font-display font-semibold">{formatNumber(downloadCount)}</div>
                <div className="text-xs text-paper-dim mt-1">Downloads</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="container-flint py-4">
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          {siteConfig.categories.map((c) => {
            const Icon = iconMap[c.icon] ?? Blocks;
            return (
              <Link
                key={c.slug}
                href={`/browse/${c.slug}`}
                className="glass hover:glass-raised rounded-xl2 p-5 flex flex-col gap-3 transition-colors"
              >
                <Icon size={20} className="text-ring" />
                <span className="text-sm font-medium">{c.label}</span>
              </Link>
            );
          })}
        </div>
      </section>

      {/* Featured */}
      {featured.length > 0 && (
        <section className="container-flint py-16">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-semibold">Featured</h2>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            {featured.map((r) => (
              <ResourceCard key={r.id} resource={r as any} />
            ))}
          </div>
        </section>
      )}

      {/* Recent */}
      <section className="container-flint py-16">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-semibold">Newest resources</h2>
          <Link href="/browse" className="text-sm text-paper-dim hover:text-paper flex items-center gap-1">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        {recent.length === 0 ? (
          <div className="glass rounded-xl2 p-12 text-center text-paper-dim">
            Nothing published yet — be the first to submit a resource.
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {recent.map((r) => (
              <ResourceCard key={r.id} resource={r as any} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
