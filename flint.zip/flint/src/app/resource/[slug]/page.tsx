import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { formatNumber, timeAgo } from "@/lib/utils";
import { Download, Star } from "lucide-react";
import { DownloadButton } from "@/components/resource/download-button";
import { RatingWidget } from "@/components/resource/rating-widget";
import { CommentSection } from "@/components/resource/comment-section";
import { AdSlot } from "@/components/ad-slot";

export default async function ResourceDetailPage({ params }: { params: { slug: string } }) {
  const resource = await prisma.resource.findUnique({
    where: { slug: params.slug },
    include: {
      category: true,
      author: true,
      ratings: true,
      tags: { include: { tag: true } },
      files: true,
    },
  });

  if (!resource || resource.status !== "PUBLISHED") notFound();

  const avgRating =
    resource.ratings.length > 0
      ? resource.ratings.reduce((a, b) => a + b.stars, 0) / resource.ratings.length
      : null;

  return (
    <div className="container-flint py-12 grid lg:grid-cols-[1fr_320px] gap-10">
      <div>
        <span className="text-xs uppercase tracking-wide text-ring font-medium">{resource.category.label}</span>
        <h1 className="text-3xl md:text-4xl font-semibold mt-2">{resource.title}</h1>
        <p className="text-paper-dim mt-3 text-lg">{resource.summary}</p>

        <div className="flex flex-wrap items-center gap-5 mt-6 text-sm text-paper-dim">
          <span>by {resource.author.name ?? resource.author.username}</span>
          <span className="flex items-center gap-1">
            <Download size={14} /> {formatNumber(resource.downloadCount)} downloads
          </span>
          {avgRating && (
            <span className="flex items-center gap-1">
              <Star size={14} className="fill-ember text-ember" /> {avgRating.toFixed(1)} ({resource.ratings.length})
            </span>
          )}
          <span>v{resource.version}</span>
          <span>updated {timeAgo(resource.updatedAt)}</span>
        </div>

        {resource.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-4">
            {resource.tags.map((t) => (
              <span key={t.tagId} className="glass rounded-full px-3 py-1 text-xs text-paper-dim">
                {t.tag.name}
              </span>
            ))}
          </div>
        )}

        <article className="prose prose-invert mt-8 max-w-none whitespace-pre-wrap text-paper/90 leading-relaxed">
          {resource.description}
        </article>

        <AdSlot slot="resourceBelowContent" className="mt-10" />

        <div className="mt-10">
          <RatingWidget resourceId={resource.id} />
        </div>

        <div className="mt-10">
          <CommentSection resourceId={resource.id} />
        </div>
      </div>

      <aside className="space-y-5">
        <div className="glass rounded-xl2 p-5">
          <DownloadButton resourceId={resource.id} title={resource.title} />
          <p className="text-xs text-paper-dim mt-3">
            {resource.files.length} file{resource.files.length === 1 ? "" : "s"} · scanned on upload
          </p>
        </div>
        <AdSlot slot="resourceSidebar" />
      </aside>
    </div>
  );
}
