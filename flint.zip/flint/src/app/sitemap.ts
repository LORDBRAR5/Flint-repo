import { prisma } from "@/lib/prisma";
import { siteConfig } from "@config/site.config";

export default async function sitemap() {
  const resources = await prisma.resource.findMany({
    where: { status: "PUBLISHED" },
    select: { slug: true, updatedAt: true },
  });

  const staticRoutes = ["", "/browse", ...siteConfig.categories.map((c) => `/browse/${c.slug}`)];

  return [
    ...staticRoutes.map((route) => ({ url: `${siteConfig.domain.url}${route}`, lastModified: new Date() })),
    ...resources.map((r) => ({
      url: `${siteConfig.domain.url}/resource/${r.slug}`,
      lastModified: r.updatedAt,
    })),
  ];
}
