"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import toast from "react-hot-toast";
import { siteConfig } from "@config/site.config";
import { UploadCloud } from "lucide-react";

export default function UploadPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [form, setForm] = useState({
    title: "",
    summary: "",
    description: "",
    categorySlug: siteConfig.categories[0].slug,
    tags: "",
  });
  const [file, setFile] = useState<File | null>(null);
  const [submitting, setSubmitting] = useState(false);

  if (status === "loading") return null;
  if (!session) {
    return (
      <div className="container-flint py-24 text-center">
        <h1 className="text-2xl font-semibold mb-3">Sign in to submit a resource</h1>
        <p className="text-paper-dim mb-6">You need an account to publish to Flint.</p>
        <a href="/login" className="rounded-full bg-paper text-ink px-6 py-3 font-medium">Sign in</a>
      </div>
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch("/api/resources", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          tags: form.tags.split(",").map((t) => t.trim()).filter(Boolean),
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        toast.error(err.error ?? "Couldn't create resource");
        return;
      }
      const { resource } = await res.json();

      if (file) {
        const fd = new FormData();
        fd.append("file", file);
        const fileRes = await fetch(`/api/resources/${resource.id}/files`, { method: "POST", body: fd });
        if (!fileRes.ok) toast.error("Resource created, but the file upload failed.");
      }

      toast.success("Submitted for review!");
      router.push("/dashboard");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="container-flint py-12 max-w-2xl">
      <h1 className="text-3xl font-semibold mb-2">Submit a resource</h1>
      <p className="text-paper-dim mb-8">
        New submissions go to review before appearing publicly. Keep descriptions clear and include setup steps.
      </p>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div>
          <label className="text-sm font-medium block mb-1.5">Title</label>
          <input
            required
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm"
            placeholder="e.g. Skyblock Economy Plugin"
          />
        </div>
        <div>
          <label className="text-sm font-medium block mb-1.5">Category</label>
          <select
            value={form.categorySlug}
            onChange={(e) => setForm({ ...form, categorySlug: e.target.value })}
            className="w-full glass rounded-lg px-4 py-3 outline-none text-sm bg-ink-soft"
          >
            {siteConfig.categories.map((c) => (
              <option key={c.slug} value={c.slug}>{c.label}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="text-sm font-medium block mb-1.5">Short summary</label>
          <input
            required
            maxLength={200}
            value={form.summary}
            onChange={(e) => setForm({ ...form, summary: e.target.value })}
            className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm"
            placeholder="One sentence — shown on cards and search"
          />
        </div>
        <div>
          <label className="text-sm font-medium block mb-1.5">Full description</label>
          <textarea
            required
            rows={8}
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm resize-y"
            placeholder="Setup steps, requirements, permissions, commands…"
          />
        </div>
        <div>
          <label className="text-sm font-medium block mb-1.5">Tags (comma separated)</label>
          <input
            value={form.tags}
            onChange={(e) => setForm({ ...form, tags: e.target.value })}
            className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm"
            placeholder="economy, skyblock, paper"
          />
        </div>
        <div>
          <label className="text-sm font-medium block mb-1.5">File</label>
          <label className="glass rounded-lg px-4 py-6 flex flex-col items-center gap-2 cursor-pointer text-sm text-paper-dim hover:text-paper transition-colors">
            <UploadCloud size={20} />
            {file ? file.name : `Click to attach (max ${siteConfig.limits.maxUploadMb}MB)`}
            <input type="file" className="hidden" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          </label>
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full rounded-full bg-paper text-ink font-medium py-3 hover:bg-white transition-colors disabled:opacity-60"
        >
          {submitting ? "Submitting…" : "Submit for review"}
        </button>
      </form>
    </div>
  );
}
