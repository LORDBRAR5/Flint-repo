import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatNumber, timeAgo } from "@/lib/utils";
import { StatusPill } from "@/components/status-pill";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  if (!session?.user) redirect("/login");

  const userId = (session.user as any).id;
  const resources = await prisma.resource.findMany({
    where: { authorId: userId },
    orderBy: { createdAt: "desc" },
    include: { category: true },
  });

  const totalDownloads = resources.reduce((a, r) => a + r.downloadCount, 0);

  return (
    <div className="container-flint py-12">
      <h1 className="text-3xl font-semibold mb-1">Your dashboard</h1>
      <p className="text-paper-dim mb-8">Manage your submissions and track their performance.</p>

      <div className="grid grid-cols-3 gap-4 mb-10 max-w-lg">
        <div className="glass rounded-xl2 p-4">
          <div className="text-2xl font-display font-semibold">{resources.length}</div>
          <div className="text-xs text-paper-dim mt-1">Submissions</div>
        </div>
        <div className="glass rounded-xl2 p-4">
          <div className="text-2xl font-display font-semibold">{formatNumber(totalDownloads)}</div>
          <div className="text-xs text-paper-dim mt-1">Downloads</div>
        </div>
        <div className="glass rounded-xl2 p-4">
          <div className="text-2xl font-display font-semibold">
            {resources.filter((r) => r.status === "PENDING_REVIEW").length}
          </div>
          <div className="text-xs text-paper-dim mt-1">In review</div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Your resources</h2>
        <Link href="/upload" className="text-sm rounded-full px-4 py-2 bg-paper text-ink font-medium">
          Submit new
        </Link>
      </div>

      {resources.length === 0 ? (
        <div className="glass rounded-xl2 p-12 text-center text-paper-dim">
          You haven't submitted anything yet.
        </div>
      ) : (
        <div className="glass rounded-xl2 divide-y divide-white/[0.06]">
          {resources.map((r) => (
            <div key={r.id} className="p-4 flex items-center justify-between gap-4">
              <div>
                <div className="font-medium">{r.title}</div>
                <div className="text-xs text-paper-dim mt-1">
                  {r.category.label} · {formatNumber(r.downloadCount)} downloads · updated {timeAgo(r.updatedAt)}
                </div>
              </div>
              <StatusPill status={r.status} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
