"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import toast from "react-hot-toast";
import { AuthCard } from "@/components/auth/auth-card";
import { SocialButtons } from "@/components/auth/social-buttons";

export default function LoginPage() {
  const router = useRouter();
  const params = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    const res = await signIn("credentials", { email, password, redirect: false });
    setLoading(false);

    if (res?.error === "EMAIL_NOT_VERIFIED") {
      toast.error("Verify your email first.");
      router.push(`/verify?email=${encodeURIComponent(email)}`);
      return;
    }
    if (res?.error === "ACCOUNT_BANNED") {
      toast.error("This account has been suspended.");
      return;
    }
    if (res?.error) {
      toast.error("Incorrect email or password.");
      return;
    }
    router.push(params.get("callbackUrl") || "/dashboard");
  }

  return (
    <AuthCard title="Welcome back" subtitle="Sign in to manage your submissions and downloads.">
      <SocialButtons />
      <div className="flex items-center gap-3 my-5">
        <div className="h-px bg-white/10 flex-1" />
        <span className="text-xs text-paper-dim">or</span>
        <div className="h-px bg-white/10 flex-1" />
      </div>
      <form onSubmit={handleSubmit} className="space-y-3">
        <input
          type="email" required placeholder="Email" value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm"
        />
        <input
          type="password" required placeholder="Password" value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="w-full glass rounded-lg px-4 py-3 outline-none focus:ring-1 focus:ring-ring text-sm"
        />
        <button
          type="submit" disabled={loading}
          className="w-full rounded-full bg-paper text-ink font-medium py-3 hover:bg-white transition-colors disabled:opacity-60"
        >
          {loading ? "Signing in…" : "Sign in"}
        </button>
      </form>
      <p className="text-sm text-paper-dim text-center mt-5">
        No account? <Link href="/register" className="text-ring-glow hover:underline">Create one</Link>
      </p>
    </AuthCard>
  );
}
