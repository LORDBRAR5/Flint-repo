import { siteConfig } from "@config/site.config";

export default function robots() {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/admin", "/dashboard", "/api"] }],
    sitemap: `${siteConfig.domain.url}/sitemap.xml`,
  };
}
