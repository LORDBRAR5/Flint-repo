import "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: "USER" | "MODERATOR" | "ADMIN";
      username: string | null;
    } & DefaultSession["user"];
  }
}

import { DefaultSession } from "next-auth";
