import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function requireAdmin() {
  const session = await getServerSession(authOptions);
  const role = (session?.user as any)?.role;
  if (!session?.user || (role !== "ADMIN" && role !== "MODERATOR")) {
    return { ok: false as const, session: null };
  }
  return { ok: true as const, session };
}

export async function logAdminAction(actorId: string, action: string, target?: string, meta?: Record<string, unknown>) {
  await prisma.adminLog.create({
    data: { actorId, action, target, meta: meta ? JSON.stringify(meta) : undefined },
  });
}
