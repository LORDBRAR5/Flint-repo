import nodemailer from "nodemailer";
import { siteConfig } from "@config/site.config";

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT || 587),
  secure: process.env.SMTP_SECURE === "true",
  auth: process.env.SMTP_USER
    ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD }
    : undefined,
});

export async function sendMail(to: string, subject: string, html: string) {
  if (!process.env.SMTP_HOST) {
    console.warn(`[mailer] SMTP not configured — skipped email to ${to}: ${subject}`);
    return;
  }
  await transporter.sendMail({
    from: `"${siteConfig.email.fromName}" <${siteConfig.email.fromAddress}>`,
    to,
    subject,
    html,
  });
}

export function verificationCodeEmail(code: string) {
  return `
  <div style="font-family:Inter,Arial,sans-serif;background:#0A0A0C;padding:32px;color:#F6F5F1">
    <h2 style="color:#F6F5F1;margin-bottom:4px">Verify your Flint account</h2>
    <p style="color:#C9C8C2">Enter this code to finish setting up your account. It expires in 15 minutes.</p>
    <div style="font-size:32px;letter-spacing:8px;font-weight:700;background:#1B1B1F;border:1px solid #2A2A30;border-radius:12px;padding:16px 24px;text-align:center;margin:24px 0;color:#B4A9FF">
      ${code}
    </div>
    <p style="color:#6b6b70;font-size:13px">If you didn't request this, you can ignore this email.</p>
  </div>`;
}
