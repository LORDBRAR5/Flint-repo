# Flint

Free Minecraft plugins, worlds, server setups, Discord templates and bot
configs — built and reviewed by the community. Next.js 14 (App Router),
Prisma + SQLite, NextAuth (Discord / Google / Email+Password with
verification codes), and a full admin dashboard.

## Quick start on your VPS

```bash
unzip flint.zip -d flint && cd flint
bash scripts/setup.sh
```

The script installs Node if it's missing, generates `.env` from
`.env.example` (with a random `NEXTAUTH_SECRET`), installs dependencies,
sets up the SQLite database, seeds categories, and builds the app.

After it finishes:

1. Open `.env` and fill in:
   - `DISCORD_CLIENT_ID` / `DISCORD_CLIENT_SECRET` — from the [Discord
     Developer Portal](https://discord.com/developers/applications). Redirect
     URL: `https://flint.atxcloud.ggff.net/api/auth/callback/discord`
   - `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` — from [Google Cloud
     Console](https://console.cloud.google.com/apis/credentials). Redirect
     URL: `https://flint.atxcloud.ggff.net/api/auth/callback/google`
   - `SMTP_*` — any SMTP provider (Resend, SES, Mailgun, etc.) to send
     verification codes as `noreply@flint.qzz.io`
   - `BOOTSTRAP_ADMIN_EMAIL` — your email. First sign-in matching this
     becomes `ADMIN` automatically.
2. Open `config/site.config.ts` and set your real domain, socials, and
   category list — everything link/domain/branding related lives in this
   one file.
3. Run it:
   ```bash
   npm start                                    # :3000
   # or, for a persistent process:
   npm i -g pm2 && pm2 start npm --name flint -- start
   ```
4. Point `cloudflared` (or your reverse proxy) at `localhost:3000` for both
   `flint.atxcloud.ggff.net` (staging) and `flint.qzz.io` (production) once
   DNS is ready.

## What's actually built

- **Auth**: Discord, Google, and email/password with a 6-digit email
  verification code flow. Session-based role gating (`USER` /
  `MODERATOR` / `ADMIN`).
- **Resource marketplace**: categories, submission with file upload,
  moderation queue, ratings, comments, download tracking, tags, search,
  sitemap.
- **Admin dashboard**: overview stats + 30-day chart, resource
  moderation (approve/reject/feature/delete), user management
  (ban/promote), analytics by category, a full audit log of every admin
  action, and site-wide settings (maintenance mode, signup toggle,
  announcement banner).
- **Ad-ready**: a neutral `<AdSlot>` component and `/ads.txt` route
  wired to `config/site.config.ts` — flip `NEXT_PUBLIC_ADS_ENABLED=true`
  and drop in your network's slot IDs once you're approved; no layout
  changes needed.
- **One config file**: `config/site.config.ts` holds every link,
  domain, email identity, category, and limit. `.env` holds actual
  secrets.

## What's intentionally left for you

This is a real, working foundation — not a mockup — but a few things
need your input before launch, since they're not mine to decide:

- **OAuth apps**: you need to create the Discord and Google apps
  yourself (they require your own accounts/branding).
- **SMTP provider**: pick one and drop credentials in `.env`.
- **Ad network**: sign up, get approved, then flip the config flag.
- **Logo**: `public/icons/flint-mark.svg` is a placeholder moon-and-ring
  mark — swap it for your real logo when it's ready; every reference
  reads from `config/site.config.ts` so you only replace the file.
- **File storage at scale**: uploads currently write to local disk
  (`UPLOADS_DIR`). Fine for a VPS; move to S3/R2 later if you outgrow it.
- **Malware scanning on uploads**: not included — worth adding
  (e.g. ClamAV) before accepting public file uploads at scale.

## Structure

```
config/site.config.ts     — all links, domains, email, categories (edit this)
prisma/schema.prisma       — database models
src/app/                   — pages + API routes (App Router)
src/app/admin/              — admin dashboard
src/app/api/admin/          — admin-only API routes
src/components/            — UI components
scripts/setup.sh           — one-shot install/build script
.env.example                — secrets template
```

## Local development

```bash
npm install
cp .env.example .env   # fill in values
npx prisma db push
npm run db:seed
npm run dev
```
