import { PrismaClient } from "@prisma/client";
import { siteConfig } from "../config/site.config";

const prisma = new PrismaClient();

async function main() {
  for (const c of siteConfig.categories) {
    await prisma.category.upsert({
      where: { slug: c.slug },
      update: { label: c.label, icon: c.icon },
      create: { slug: c.slug, label: c.label, icon: c.icon },
    });
  }
  console.log(`Seeded ${siteConfig.categories.length} categories.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
