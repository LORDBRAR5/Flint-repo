/**
 * FLINT — Central Configuration
 * ─────────────────────────────────────────────────────────────
 * This is the ONLY file you should need to edit for branding,
 * domains, links, and identity values that aren't secrets.
 *
 * Actual secrets (API keys, client secrets, DB URLs, SMTP
 * passwords) live in `.env` — this file reads them from
 * `process.env` so nothing sensitive is hardcoded here.
 * See `.env.example` for the full list of variables to set.
 * ─────────────────────────────────────────────────────────────
 */

export const siteConfig = {
  name: "Flint",
  tagline: "Everything you need to build your server.",
  description:
    "Free Minecraft plugins, worlds, server setups, Discord templates and bot configs — built and reviewed by the community.",

  // Domains
  domain: {
    production: "flint.qzz.io",
    staging: "flint.atxcloud.ggff.net",
    get url() {
      return process.env.NODE_ENV === "production"
        ? `https://${this.production}`
        : `https://${this.staging}`;
    },
  },

  // Email identity (SMTP credentials themselves go in .env)
  email: {
    fromName: "Flint",
    fromAddress: "noreply@flint.qzz.io",
    supportAddress: "support@flint.qzz.io",
  },

  // Social / external links — edit freely, referenced everywhere via this object
  links: {
    discord: "https://discord.gg/your-invite",
    youtube: "https://youtube.com/@flint",
    instagram: "https://instagram.com/flint",
    github: "https://github.com/LORDBRAR747",
    status: "https://status.flint.qzz.io",
  },

  // Branding
  brand: {
    logoPlaceholder: "/icons/flint-mark.svg", // swap when your real logo is ready
    accentPrimary: "#8B7CFF", // ring violet
    accentSecondary: "#FF6B4A", // flint ember
  },

  // Ads / monetization slots (wire up your network's script + slot IDs later)
  ads: {
    enabled: process.env.NEXT_PUBLIC_ADS_ENABLED === "true",
    provider: process.env.NEXT_PUBLIC_ADS_PROVIDER || "", // e.g. "adsense", "ezoic", "media.net"
    clientId: process.env.NEXT_PUBLIC_ADS_CLIENT_ID || "",
    slots: {
      resourceSidebar: process.env.NEXT_PUBLIC_AD_SLOT_SIDEBAR || "",
      resourceBelowContent: process.env.NEXT_PUBLIC_AD_SLOT_BELOW_CONTENT || "",
      homeInline: process.env.NEXT_PUBLIC_AD_SLOT_HOME || "",
    },
    // ads.txt content is generated from this at /public/ads.txt build step — see scripts/setup.sh
  },

  // Resource categories shown across the site (add/remove freely)
  categories: [
    { slug: "minecraft-plugins", label: "Minecraft Plugins", icon: "Blocks" },
    { slug: "minecraft-worlds", label: "Worlds & Maps", icon: "Mountain" },
    { slug: "server-setups", label: "Server Setups", icon: "Server" },
    { slug: "discord-templates", label: "Discord Templates", icon: "LayoutTemplate" },
    { slug: "discord-bots", label: "Discord Bot Setups", icon: "Bot" },
    { slug: "dev-tools", label: "Dev Tools & Scripts", icon: "Code2" },
  ],

  limits: {
    maxUploadMb: 200,
    freeUserDailyDownloads: 40,
  },
} as const;

export type SiteConfig = typeof siteConfig;
