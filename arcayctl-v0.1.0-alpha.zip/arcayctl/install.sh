#!/usr/bin/env bash
#
# Arcayctl Installer
# Professional single-command installer for Ubuntu 22.04/24.04 & Debian 12/13
# Usage: curl -sSL https://raw.githubusercontent.com/YOUR_USER/arcayctl/main/install.sh | bash
#        or: bash install.sh
#

set -euo pipefail

# ─────────────────────────────────────────────
# Colors & Styling
# ─────────────────────────────────────────────
RED='\033[0;31m'
CRIMSON='\033[38;2;225;29;72m'
BLACK='\033[0;30m'
BOLD='\033[1m'
DIM='\033[2m'
NC='\033[0m'
BG_DARK='\033[48;5;234m'

# ─────────────────────────────────────────────
# Global Config
# ─────────────────────────────────────────────
ARCAYCTL_VERSION="0.1.0-alpha"
ARCAYCTL_DIR="/opt/arcayctl"
PANEL_DIR="${ARCAYCTL_DIR}/panel"
DAEMON_DIR="${ARCAYCTL_DIR}/daemon"
LOG_FILE="/var/log/arcayctl-install.log"
GITHUB_REPO="https://github.com/YOUR_USERNAME/arcayctl"   # Change after you push
MIN_RAM_MB=2048
REQUIRED_OS=("ubuntu" "debian")

# ─────────────────────────────────────────────
# Utility Functions
# ─────────────────────────────────────────────
print_banner() {
    clear
    echo -e "${CRIMSON}"
    cat << 'EOF'
    ___                    __  __
   /   |  ______________ _/ /_/ /_
  / /| | / ___/ ___/ __ `/ __/ __ \
 / ___ |/ /  / /__/ /_/ / /_/ / / /
/_/  |_/_/   \___/\__,_/\__/_/ /_/
EOF
    echo -e "${NC}"
    echo -e "  ${BOLD}Arcayctl${NC}  •  Modern Game Server Management Panel"
    echo -e "  ${DIM}Version ${ARCAYCTL_VERSION}  •  Ubuntu & Debian${NC}"
    echo -e "  ${DIM}──────────────────────────────────────────────${NC}"
    echo
}

log() {
    local level="$1"
    shift
    local msg="$*"
    local ts
    ts=$(date '+%Y-%m-%d %H:%M:%S')
    echo "[$ts] [$level] $msg" >> "$LOG_FILE"
}

info()  { echo -e "  ${CRIMSON}●${NC} $*"; log "INFO" "$*"; }
success(){ echo -e "  ${CRIMSON}✔${NC} $*"; log "OK" "$*"; }
warn()  { echo -e "  ${CRIMSON}!${NC} ${DIM}$*${NC}"; log "WARN" "$*"; }
error() { echo -e "  ${RED}✖${NC} $*"; log "ERROR" "$*"; exit 1; }

require_root() {
    if [[ $EUID -ne 0 ]]; then
        error "This installer must be run as root (use sudo)."
    fi
}

detect_os() {
    if [[ -f /etc/os-release ]]; then
        # shellcheck source=/dev/null
        . /etc/os-release
        OS_ID="${ID,,}"
        OS_VERSION_ID="${VERSION_ID}"
        OS_PRETTY="${PRETTY_NAME}"
    else
        error "Cannot detect OS. Only Ubuntu 22.04/24.04 and Debian 12/13 are supported."
    fi

    case "$OS_ID" in
        ubuntu)
            if [[ "$OS_VERSION_ID" != "22.04" && "$OS_VERSION_ID" != "24.04" ]]; then
                warn "Ubuntu $OS_VERSION_ID detected. Officially tested on 22.04 & 24.04."
            fi
            ;;
        debian)
            if [[ "$OS_VERSION_ID" != "12" && "$OS_VERSION_ID" != "13" ]]; then
                warn "Debian $OS_VERSION_ID detected. Officially tested on 12 & 13."
            fi
            ;;
        *)
            error "Unsupported OS: $OS_PRETTY. Only Ubuntu and Debian are supported."
            ;;
    esac
    success "Detected: $OS_PRETTY"
}

check_resources() {
    local total_ram
    total_ram=$(free -m | awk '/^Mem:/{print $2}')
    if (( total_ram < MIN_RAM_MB )); then
        warn "System has ${total_ram}MB RAM. Recommended minimum is ${MIN_RAM_MB}MB."
    fi
}

# ─────────────────────────────────────────────
# Dependency Installation
# ─────────────────────────────────────────────
install_dependencies() {
    info "Updating package lists..."
    apt-get update -qq

    info "Installing base dependencies..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
        curl wget git jq unzip tar \
        ca-certificates gnupg lsb-release \
        software-properties-common apt-transport-https \
        ufw fail2ban > /dev/null

    # Docker
    if ! command -v docker &>/dev/null; then
        info "Installing Docker..."
        curl -fsSL https://get.docker.com | sh > /dev/null
        systemctl enable --now docker
        success "Docker installed"
    else
        success "Docker already present"
    fi

    # PostgreSQL
    if ! command -v psql &>/dev/null; then
        info "Installing PostgreSQL..."
        apt-get install -y -qq postgresql postgresql-contrib > /dev/null
        systemctl enable --now postgresql
        success "PostgreSQL installed"
    else
        success "PostgreSQL already present"
    fi

    # Redis
    if ! command -v redis-server &>/dev/null; then
        info "Installing Redis..."
        apt-get install -y -qq redis-server > /dev/null
        systemctl enable --now redis-server
        success "Redis installed"
    else
        success "Redis already present"
    fi

    # Nginx
    if ! command -v nginx &>/dev/null; then
        info "Installing Nginx..."
        apt-get install -y -qq nginx > /dev/null
        systemctl enable --now nginx
        success "Nginx installed"
    else
        success "Nginx already present"
    fi

    # Node.js 20 LTS (for frontend build)
    if ! command -v node &>/dev/null || [[ $(node -v | cut -d. -f1 | tr -d v) -lt 20 ]]; then
        info "Installing Node.js 20..."
        curl -fsSL https://deb.nodesource.com/setup_20.x | bash - > /dev/null
        apt-get install -y -qq nodejs > /dev/null
        success "Node.js $(node -v) installed"
    else
        success "Node.js $(node -v) already present"
    fi

    # Go (for building panel & daemon)
    if ! command -v go &>/dev/null; then
        info "Installing Go 1.22..."
        local go_ver="1.22.5"
        wget -q "https://go.dev/dl/go${go_ver}.linux-amd64.tar.gz" -O /tmp/go.tar.gz
        rm -rf /usr/local/go
        tar -C /usr/local -xzf /tmp/go.tar.gz
        echo 'export PATH=$PATH:/usr/local/go/bin' > /etc/profile.d/go.sh
        export PATH=$PATH:/usr/local/go/bin
        success "Go installed"
    else
        success "Go already present"
    fi
}

# ─────────────────────────────────────────────
# Database Setup
# ─────────────────────────────────────────────
setup_database() {
    info "Configuring PostgreSQL for Arcayctl..."
    local db_pass
    db_pass=$(openssl rand -base64 24 | tr -d '/+=' | head -c 24)

    sudo -u postgres psql -tc "SELECT 1 FROM pg_roles WHERE rolname='arcayctl'" | grep -q 1 || \
        sudo -u postgres psql -c "CREATE USER arcayctl WITH PASSWORD '${db_pass}';" > /dev/null

    sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='arcayctl'" | grep -q 1 || \
        sudo -u postgres psql -c "CREATE DATABASE arcayctl OWNER arcayctl;" > /dev/null

    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE arcayctl TO arcayctl;" > /dev/null

    mkdir -p /etc/arcayctl
    cat > /etc/arcayctl/database.env <<EOF
DB_HOST=127.0.0.1
DB_PORT=5432
DB_NAME=arcayctl
DB_USER=arcayctl
DB_PASSWORD=${db_pass}
EOF
    chmod 600 /etc/arcayctl/database.env
    success "Database configured (credentials saved to /etc/arcayctl/database.env)"
}

# ─────────────────────────────────────────────
# Panel Installation
# ─────────────────────────────────────────────
install_panel() {
    info "Installing Arcayctl Panel..."

    mkdir -p "$PANEL_DIR" /var/www/arcayctl

    # Placeholder: In real release this would download release tarball
    # For now we copy from local source if present, else create skeleton
    if [[ -d "$(dirname "$0")/panel" ]]; then
        cp -a "$(dirname "$0")/panel/." "$PANEL_DIR/"
    else
        mkdir -p "$PANEL_DIR"/{backend,frontend}
        # Create minimal placeholders so services can start later
        echo "Panel source will be pulled from GitHub releases in production." > "$PANEL_DIR/README.md"
    fi

    # Create systemd service
    cat > /etc/systemd/system/arcayctl-panel.service << 'EOF'
[Unit]
Description=Arcayctl Panel
After=network.target postgresql.service redis-server.service
Wants=postgresql.service redis-server.service

[Service]
Type=simple
User=www-data
Group=www-data
WorkingDirectory=/opt/arcayctl/panel
EnvironmentFile=/etc/arcayctl/database.env
ExecStart=/opt/arcayctl/panel/backend/arcayctl-panel
Restart=on-failure
RestartSec=5
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    success "Panel files & service prepared"
    info "Note: Full binary build happens after you push source to GitHub and create releases."
}

# ─────────────────────────────────────────────
# Daemon (Wings equivalent) Installation
# ─────────────────────────────────────────────
install_daemon() {
    info "Installing Arcayctl Daemon (Wings equivalent)..."

    mkdir -p "$DAEMON_DIR" /etc/arcayctl/daemon /var/lib/arcayctl/volumes /var/log/arcayctl

    if [[ -d "$(dirname "$0")/daemon" ]]; then
        cp -a "$(dirname "$0")/daemon/." "$DAEMON_DIR/"
    else
        mkdir -p "$DAEMON_DIR"
        echo "Daemon source placeholder" > "$DAEMON_DIR/README.md"
    fi

    # Config
    cat > /etc/arcayctl/daemon/config.yml << EOF
# Arcayctl Daemon Configuration
debug: false
uuid: $(cat /proc/sys/kernel/random/uuid)
token_id: ""
token: ""
api:
  host: 0.0.0.0
  port: 8080
  ssl:
    enabled: false
    cert: /etc/letsencrypt/live/example.com/fullchain.pem
    key: /etc/letsencrypt/live/example.com/privkey.pem
system:
  data: /var/lib/arcayctl/volumes
  sftp:
    bind_port: 2022
allowed_mounts: []
remote: "http://127.0.0.1:80"
EOF

    # Systemd
    cat > /etc/systemd/system/arcayctl-daemon.service << 'EOF'
[Unit]
Description=Arcayctl Daemon
After=docker.service
Requires=docker.service

[Service]
User=root
WorkingDirectory=/opt/arcayctl/daemon
LimitNOFILE=4096
PIDFile=/var/run/arcayctl-daemon.pid
ExecStart=/opt/arcayctl/daemon/arcayctl-daemon --config /etc/arcayctl/daemon/config.yml
Restart=on-failure
StartLimitInterval=180
StartLimitBurst=30
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

    systemctl daemon-reload
    success "Daemon installed & configured"
}

# ─────────────────────────────────────────────
# Uninstall
# ─────────────────────────────────────────────
uninstall_panel() {
    info "Uninstalling Panel..."
    systemctl stop arcayctl-panel 2>/dev/null || true
    systemctl disable arcayctl-panel 2>/dev/null || true
    rm -f /etc/systemd/system/arcayctl-panel.service
    rm -rf "$PANEL_DIR" /var/www/arcayctl
    systemctl daemon-reload
    success "Panel removed"
}

uninstall_daemon() {
    info "Uninstalling Daemon..."
    systemctl stop arcayctl-daemon 2>/dev/null || true
    systemctl disable arcayctl-daemon 2>/dev/null || true
    rm -f /etc/systemd/system/arcayctl-daemon.service
    rm -rf "$DAEMON_DIR" /etc/arcayctl/daemon
    systemctl daemon-reload
    success "Daemon removed"
}

# ─────────────────────────────────────────────
# Update
# ─────────────────────────────────────────────
update_component() {
    local component="$1"
    info "Updating $component..."
    warn "Update will pull the latest release from GitHub once the repository is public."
    # Placeholder for real update logic:
    # curl -sSL https://api.github.com/repos/.../releases/latest ...
    success "Update check completed (no newer version or source not yet published)"
}

# ─────────────────────────────────────────────
# Status
# ─────────────────────────────────────────────
show_status() {
    echo
    echo -e "  ${BOLD}Service Status${NC}"
    echo -e "  ────────────────────────────────────"
    for svc in arcayctl-panel arcayctl-daemon docker postgresql redis-server nginx; do
        if systemctl is-active --quiet "$svc" 2>/dev/null; then
            echo -e "  ${CRIMSON}●${NC} $svc  ${DIM}(running)${NC}"
        else
            echo -e "  ${DIM}○ $svc  (stopped/not installed)${NC}"
        fi
    done
    echo
}

# ─────────────────────────────────────────────
# Interactive Menus
# ─────────────────────────────────────────────
main_menu() {
    while true; do
        print_banner
        echo -e "  ${BOLD}What would you like to manage?${NC}"
        echo
        echo -e "  ${CRIMSON}1${NC})  Panel"
        echo -e "  ${CRIMSON}2${NC})  Daemon (Wings equivalent)"
        echo -e "  ${CRIMSON}3${NC})  Both (Panel + Daemon)"
        echo -e "  ${CRIMSON}4${NC})  Status"
        echo -e "  ${CRIMSON}5${NC})  Full Uninstall"
        echo -e "  ${CRIMSON}0${NC})  Exit"
        echo
        read -rp "  Select option [0-5]: " choice
        case "$choice" in
            1) component_menu "panel" ;;
            2) component_menu "daemon" ;;
            3) component_menu "both" ;;
            4) show_status; read -rp "  Press Enter to continue..." ;;
            5)
                read -rp "  Are you sure you want to fully uninstall Arcayctl? [y/N]: " conf
                if [[ "${conf,,}" == "y" ]]; then
                    uninstall_panel
                    uninstall_daemon
                    rm -rf /etc/arcayctl /opt/arcayctl /var/lib/arcayctl
                    success "Arcayctl completely removed"
                fi
                ;;
            0) echo; exit 0 ;;
            *) warn "Invalid option" ;;
        esac
    done
}

component_menu() {
    local comp="$1"
    while true; do
        print_banner
        echo -e "  ${BOLD}${comp^^} Management${NC}"
        echo
        echo -e "  ${CRIMSON}1${NC})  Install"
        echo -e "  ${CRIMSON}2${NC})  Uninstall"
        echo -e "  ${CRIMSON}3${NC})  Update"
        echo -e "  ${CRIMSON}4${NC})  Status"
        echo -e "  ${CRIMSON}0${NC})  Back"
        echo
        read -rp "  Select option [0-4]: " choice
        case "$choice" in
            1)
                require_root
                detect_os
                check_resources
                install_dependencies
                setup_database
                if [[ "$comp" == "panel" || "$comp" == "both" ]]; then
                    install_panel
                fi
                if [[ "$comp" == "daemon" || "$comp" == "both" ]]; then
                    install_daemon
                fi
                echo
                success "Installation finished!"
                echo
                echo -e "  Next steps:"
                echo -e "  1. Edit /etc/arcayctl/daemon/config.yml (if using daemon)"
                echo -e "  2. Build the binaries from source (or wait for official releases)"
                echo -e "  3. systemctl enable --now arcayctl-panel arcayctl-daemon"
                echo
                read -rp "  Press Enter to continue..."
                ;;
            2)
                require_root
                if [[ "$comp" == "panel" || "$comp" == "both" ]]; then uninstall_panel; fi
                if [[ "$comp" == "daemon" || "$comp" == "both" ]]; then uninstall_daemon; fi
                read -rp "  Press Enter to continue..."
                ;;
            3)
                require_root
                if [[ "$comp" == "panel" || "$comp" == "both" ]]; then update_component "panel"; fi
                if [[ "$comp" == "daemon" || "$comp" == "both" ]]; then update_component "daemon"; fi
                read -rp "  Press Enter to continue..."
                ;;
            4) show_status; read -rp "  Press Enter to continue..." ;;
            0) return ;;
            *) warn "Invalid option" ;;
        esac
    done
}

# ─────────────────────────────────────────────
# Entry Point
# ─────────────────────────────────────────────
main() {
    mkdir -p /var/log
    touch "$LOG_FILE"
    require_root
    detect_os
    main_menu
}

main "$@"
