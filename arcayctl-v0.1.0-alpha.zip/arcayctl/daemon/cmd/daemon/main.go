package main

import (
	"flag"
	"log"
	"os"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/logger"
	"github.com/gofiber/fiber/v2/middleware/recover"
)

func main() {
	configPath := flag.String("config", "/etc/arcayctl/daemon/config.yml", "Path to daemon config")
	flag.Parse()

	log.Printf("Arcayctl Daemon starting with config: %s", *configPath)

	// TODO: Load YAML config, connect to Docker, register with Panel

	app := fiber.New(fiber.Config{
		AppName: "Arcayctl Daemon",
	})

	app.Use(recover.New())
	app.Use(logger.New())

	app.Get("/api/system", func(c *fiber.Ctx) error {
		return c.JSON(fiber.Map{
			"version": "0.1.0-alpha",
			"status":  "ready",
			"docker":  "connected (placeholder)",
		})
	})

	port := os.Getenv("DAEMON_PORT")
	if port == "" {
		port = "8080"
	}

	log.Printf("Daemon listening on :%s", port)
	if err := app.Listen(":" + port); err != nil {
		log.Fatal(err)
	}
}
