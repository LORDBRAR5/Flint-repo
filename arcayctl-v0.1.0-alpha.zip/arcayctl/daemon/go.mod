module github.com/arcayctl/daemon

go 1.22

require (
        github.com/docker/docker v26.1.3+incompatible
        github.com/gofiber/fiber/v2 v2.52.5
        gopkg.in/yaml.v3 v3.0.1
)
