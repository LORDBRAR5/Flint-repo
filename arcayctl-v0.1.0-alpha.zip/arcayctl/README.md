# Arcayctl

**Modern • Glassmorphism • Professional Game Server Management Panel**

Arcayctl is a next-generation game server control panel designed for Ubuntu & Debian.  
It aims to be smoother, more beautiful, and more feature-rich than traditional panels while remaining easy to install and operate.

> **Status**: Early Alpha (v0.1.0) – Foundation + Installer + Architecture ready.  
> Full production features are being built iteratively.

---

## Highlights

- **Single-command interactive installer** for Ubuntu 22.04/24.04 and Debian 12/13
- **Glassmorphism UI** by default (frosted glass, depth, smooth animations)
- **Default theme**: Crimson Red + Deep Black
- **Extra themes**: Spiderman (webs, masks, animations), Tech, Professional, Midnight, Cyber, and more
- **Panel + Daemon** architecture (compatible with the classic Wings model)
- Docker-isolated game servers
- Modern stack: Go backend, Next.js frontend, PostgreSQL, Redis
- Designed for extreme smoothness and professional aesthetics

---

## Quick Install (Ubuntu / Debian)

```bash
# Download and run the installer
curl -sSL https://raw.githubusercontent.com/YOUR_USERNAME/arcayctl/main/install.sh | sudo bash
```

Or clone the repository and run locally:

```bash
git clone https://github.com/YOUR_USERNAME/arcayctl.git
cd arcayctl
sudo bash install.sh
```

The installer presents a clean interactive menu:

```
1) Panel
2) Daemon (Wings equivalent)
3) Both
4) Status
5) Full Uninstall
```

Each component then offers:

1. Install  
2. Uninstall  
3. Update  
4. Status  

---

## Architecture

```
┌─────────────────┐       ┌──────────────────────┐
│   Arcayctl      │◄─────►│  Arcayctl Daemon     │
│   Panel         │  API  │  (per node)          │
│  (Next.js + Go) │       │  Docker + SFTP + WS  │
└─────────────────┘       └──────────────────────┘
         │
         ▼
   PostgreSQL + Redis
```

- **Panel**: Web UI + API (authentication, users, servers, eggs, themes, etc.)
- **Daemon**: Runs on every node, manages Docker containers, console, files, backups, SFTP

---

## Project Structure

```
arcayctl/
├── install.sh              # Main interactive installer
├── panel/
│   ├── backend/            # Go API server
│   └── frontend/           # Next.js + Tailwind + Framer Motion
├── daemon/                 # Go daemon (Wings equivalent)
├── themes/                 # Theme packs (CSS variables + assets)
├── scripts/                # Helper scripts
├── docker/                 # Docker Compose for development
└── docs/                   # Documentation
```

---

## Theme System

Default theme uses pure glassmorphism with a crimson/red accent on near-black backgrounds.

**Spiderman Theme** (planned / in progress):
- Animated web backgrounds
- Mask stickers & overlays
- Web patterns on resource cards
- Subtle particle and swing effects
- Red / blue accent palette

Themes are pure CSS variable packs + optional JS animations, so switching is instant and zero performance cost when not active.

---

## Roadmap (High Level)

### Phase 1 – Foundation (Current)
- [x] Professional interactive installer
- [x] Project structure
- [x] Theme engine skeleton
- [ ] Core Go API (auth, users, nodes)
- [ ] Basic Next.js dashboard with glassmorphism

### Phase 2 – Core Features
- [ ] Server lifecycle (create / start / stop / console)
- [ ] File manager + SFTP
- [ ] Eggs / Nests system
- [ ] Backups & Schedules
- [ ] Resource monitoring

### Phase 3 – Advanced
- [ ] Full Spiderman + extra themes
- [ ] Plugin system
- [ ] Billing / Store module (optional)
- [ ] AI assistant
- [ ] Migration tool from Pterodactyl

---

## Requirements

| Component | Minimum |
|-----------|---------|
| OS        | Ubuntu 22.04 / 24.04 or Debian 12 / 13 |
| RAM       | 2 GB (4 GB+ recommended) |
| CPU       | 2 cores |
| Disk      | 20 GB+ |
| Software  | Docker, PostgreSQL, Redis, Nginx (installed automatically) |

---

## Security Notes

- Installer creates a dedicated PostgreSQL user with a strong random password
- Credentials stored in `/etc/arcayctl/` with restricted permissions
- Daemon runs as root (required for Docker) but containers are isolated
- Recommended: enable UFW + Fail2Ban (installer prepares the packages)

---

## Contributing & Development

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Open a Pull Request

Local development:

```bash
# Frontend
cd panel/frontend
npm install
npm run dev

# Backend (once implemented)
cd panel/backend
go run .

# Daemon
cd daemon
go run .
```

---

## License

MIT License – see [LICENSE](LICENSE)

---

**Arcayctl** – Built for beauty, speed, and control.
