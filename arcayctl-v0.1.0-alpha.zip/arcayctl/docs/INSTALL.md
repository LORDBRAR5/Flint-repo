# Arcayctl Installation Guide

## Supported Systems

- Ubuntu 22.04 LTS
- Ubuntu 24.04 LTS
- Debian 12
- Debian 13

## One-Command Install

```bash
curl -sSL https://raw.githubusercontent.com/YOUR_USERNAME/arcayctl/main/install.sh | sudo bash
```

The installer is fully interactive.

### Menu Flow

1. Choose component:
   - Panel
   - Daemon
   - Both
   - Status
   - Full Uninstall

2. For Panel or Daemon you then choose:
   - Install
   - Uninstall
   - Update
   - Status

## What the Installer Does

- Detects OS and validates support
- Installs Docker, PostgreSQL, Redis, Nginx, Node.js, Go
- Creates a dedicated PostgreSQL user + database with random strong password
- Places configuration under `/etc/arcayctl/`
- Creates systemd services for Panel and Daemon
- Sets up log directories and data volumes

## After Installation

1. Review `/etc/arcayctl/database.env`
2. Review `/etc/arcayctl/daemon/config.yml`
3. Build the binaries from source (or wait for official GitHub releases)
4. Enable and start services:

```bash
sudo systemctl enable --now arcayctl-panel
sudo systemctl enable --now arcayctl-daemon
```

## Uninstall

Use the interactive installer and choose the Uninstall options, or run:

```bash
sudo bash install.sh
# then select Full Uninstall
```

## Security Recommendations

- Keep the firewall enabled (`ufw`)
- Use Fail2Ban (package is installed by the installer)
- Always run the Panel behind Nginx + HTTPS (Let’s Encrypt)
- Restrict SFTP and Daemon ports to trusted IPs when possible
