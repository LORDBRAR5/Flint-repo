import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Arcayctl – Game Server Management",
  description: "Modern, glassmorphism game server control panel",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="theme-default">
      <body className="min-h-screen bg-[var(--arc-bg)] text-[var(--arc-text)]">
        {children}
      </body>
    </html>
  );
}
