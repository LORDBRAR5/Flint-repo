"use client";

import { motion } from "framer-motion";
import { Server, Activity, Shield, Zap, Settings, LayoutDashboard } from "lucide-react";

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Navbar */}
      <header className="glass border-b border-[var(--arc-border)] sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[var(--arc-primary)] flex items-center justify-center font-bold text-white text-sm">
              A
            </div>
            <span className="font-semibold text-lg tracking-tight">Arcayctl</span>
          </div>
          <nav className="hidden md:flex items-center gap-8 text-sm text-[var(--arc-text-secondary)]">
            <a href="#" className="hover:text-white transition">Dashboard</a>
            <a href="#" className="hover:text-white transition">Servers</a>
            <a href="#" className="hover:text-white transition">Nodes</a>
            <a href="#" className="hover:text-white transition">Admin</a>
          </nav>
          <button className="btn-primary text-sm">Sign In</button>
        </div>
      </header>

      {/* Hero */}
      <main className="flex-1">
        <section className="max-w-7xl mx-auto px-6 pt-20 pb-16 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
              Game servers.
              <br />
              <span className="text-[var(--arc-primary)]">Beautifully managed.</span>
            </h1>
            <p className="text-lg text-[var(--arc-text-secondary)] max-w-2xl mx-auto mb-10">
              Arcayctl is a modern, glassmorphism game server panel built for speed,
              aesthetics, and complete control. Designed for Ubuntu & Debian.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <button className="btn-primary px-8 py-3 text-base">
                Get Started
              </button>
              <button className="glass px-8 py-3 text-base hover:bg-[var(--arc-surface-hover)] transition">
                View Docs
              </button>
            </div>
          </motion.div>
        </section>

        {/* Feature cards */}
        <section className="max-w-7xl mx-auto px-6 pb-24">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: <Server className="w-6 h-6" />,
                title: "Docker Isolation",
                desc: "Every game server runs in its own secure container with full resource limits.",
              },
              {
                icon: <Activity className="w-6 h-6" />,
                title: "Real-time Console",
                desc: "Live logs, command history, and low-latency WebSocket streaming.",
              },
              {
                icon: <Shield className="w-6 h-6" />,
                title: "Granular Permissions",
                desc: "50+ permissions for owners, subusers, and administrators.",
              },
              {
                icon: <Zap className="w-6 h-6" />,
                title: "Glassmorphism UI",
                desc: "Smooth animations, depth, and a stunning red & black default theme.",
              },
              {
                icon: <LayoutDashboard className="w-6 h-6" />,
                title: "Theme Engine",
                desc: "Spiderman, Tech, Professional and custom themes with one click.",
              },
              {
                icon: <Settings className="w-6 h-6" />,
                title: "One-command Install",
                desc: "Interactive installer for Panel, Daemon, updates and uninstall.",
              },
            ].map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 * i }}
                className="glass-card"
              >
                <div className="w-12 h-12 rounded-xl bg-[var(--arc-primary-soft)] text-[var(--arc-primary)] flex items-center justify-center mb-4">
                  {f.icon}
                </div>
                <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-[var(--arc-text-secondary)] leading-relaxed">
                  {f.desc}
                </p>
              </motion.div>
            ))}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-[var(--arc-border)] py-8 text-center text-sm text-[var(--arc-text-muted)]">
        Arcayctl v0.1.0-alpha • Built for beauty and control
      </footer>
    </div>
  );
}
