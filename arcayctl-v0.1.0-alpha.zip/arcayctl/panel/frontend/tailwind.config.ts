import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        arc: {
          bg: "var(--arc-bg)",
          primary: "var(--arc-primary)",
          "primary-hover": "var(--arc-primary-hover)",
          surface: "var(--arc-surface)",
          border: "var(--arc-border)",
          text: "var(--arc-text)",
          muted: "var(--arc-text-muted)",
        },
      },
      borderRadius: {
        arc: "var(--arc-radius)",
        "arc-sm": "var(--arc-radius-sm)",
      },
      boxShadow: {
        glass: "var(--arc-shadow)",
        glow: "var(--arc-shadow-glow)",
      },
      backdropBlur: {
        glass: "var(--arc-blur)",
      },
    },
  },
  plugins: [],
};

export default config;
