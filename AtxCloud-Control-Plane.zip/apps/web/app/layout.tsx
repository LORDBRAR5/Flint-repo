import './globals.css';
export const metadata={title:'AtxCloud Control Center',description:'AtxCloud hosting control center'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
