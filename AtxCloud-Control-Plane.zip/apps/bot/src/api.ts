import axios from 'axios';
const api=axios.create({baseURL:process.env.API_URL||'http://api:4000',headers:{'x-atxcloud-internal':process.env.ATXCLOUD_INTERNAL_SECRET}});
export const getUser=async(id:string)=>{try{return (await api.get(`/internal/user/${id}`)).data}catch(e:any){if(e.response?.status===404)return null;throw e}};
export const getServer=async(id:string)=>{try{return (await api.get(`/internal/server/${id}`)).data}catch(e:any){if(e.response?.status===404)return null;throw e}};
export const gift=async(fromDiscordId:string,toDiscordId:string,amount:number)=>api.post('/internal/gift-coins',{fromDiscordId,toDiscordId,amount,idempotencyKey:`gift:${fromDiscordId}:${toDiscordId}:${Date.now()}`});
export const power=async(discordId:string,publicId:string,action:string,clientKey:string)=>api.post('/internal/power',{discordId,publicId,action,clientKey});
export const reset=async(discordId:string)=> (await api.post('/internal/reset-password',{discordId})).data;
export const audit=async(actor:string,action:string,targetType?:string,targetId?:string,metadata?:any)=>api.post('/internal/audit',{actor,action,targetType,targetId,metadata});
