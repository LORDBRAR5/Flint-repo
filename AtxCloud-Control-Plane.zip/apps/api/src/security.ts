import crypto from 'crypto';
export const hash=(v:string)=>crypto.createHash('sha256').update(v).digest('hex');
export const internalOk=(v?:string)=>!!v&&crypto.timingSafeEqual(Buffer.from(hash(v)),Buffer.from(hash(process.env.ATXCLOUD_INTERNAL_SECRET||'')));
export const publicId=()=>{const a=['Stone','Dirt','Creeper','Quartz','Obsidian','Ruby','Iron','Oak','Ash','Nova'];return a[Math.floor(Math.random()*a.length)]+Math.floor(1000+Math.random()*9000)};
