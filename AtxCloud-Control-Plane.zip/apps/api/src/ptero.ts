import axios from 'axios';
const base=()=>process.env.PTERODACTYL_URL!.replace(/\/$/,'');
const app=()=>axios.create({baseURL:base()+'/api/application',headers:{Authorization:`Bearer ${process.env.PTERODACTYL_APPLICATION_KEY}`,Accept:'Application/vnd.pterodactyl.v1+json','Content-Type':'application/json'},timeout:15000});
const client=(key:string)=>axios.create({baseURL:base()+'/api/client',headers:{Authorization:`Bearer ${key}`,Accept:'Application/vnd.pterodactyl.v1+json','Content-Type':'application/json'},timeout:15000});
export async function pteroUser(id:number){return (await app().get(`/users/${id}`)).data.attributes}
export async function findUserByExternalId(externalId:string){const r=await app().get('/users',{params:{'filter[external_id]':externalId}});return r.data.data?.[0]?.attributes}
export async function deletePteroUser(id:number){await app().delete(`/users/${id}`)}
export async function listPteroServers(){let out:any[]=[];let page=1;while(true){const r=await app().get('/servers',{params:{page}});out.push(...r.data.data.map((x:any)=>x.attributes));if(!r.data.meta?.pagination||page>=r.data.meta.pagination.total_pages)break;page++}return out}
export async function powerServer(identifier:string,signal:'start'|'stop'|'restart'|'kill',clientKey:string){await client(clientKey).post(`/servers/${identifier}/power`,{signal})}
export async function serverDetails(identifier:string,clientKey:string){return (await client(clientKey).get(`/servers/${identifier}/resources`)).data.attributes}
export async function suspendServer(id:number){await app().post(`/servers/${id}/suspend`)}
export async function unsuspendServer(id:number){await app().post(`/servers/${id}/unsuspend`)}
export async function deleteServer(id:number){await app().delete(`/servers/${id}`)}
