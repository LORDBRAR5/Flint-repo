#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v docker >/dev/null || { echo 'Docker is required.'; exit 1; }
command -v openssl >/dev/null || { echo 'OpenSSL is required.'; exit 1; }
if [ ! -f .env ]; then cp .env.example .env; fi
random(){ openssl rand -hex 24; }
setenv(){ key="$1"; val="$2"; if grep -q "^${key}=" .env; then sed -i "s#^${key}=.*#${key}=${val}#" .env; else echo "${key}=${val}" >> .env; fi; }
setenv POSTGRES_PASSWORD "$(random)"; setenv ATXCLOUD_INTERNAL_SECRET "$(random)"; setenv ATXCLOUD_COOKIE_SECRET "$(random)$(random)"
echo 'AtxCloud production setup'; echo 'Press Enter to keep an existing value.'
ask(){ key="$1"; prompt="$2"; current="$(grep -E "^${key}=" .env|cut -d= -f2- || true)"; read -r -p "$prompt [$current]: " value || true; [ -n "${value:-}" ] && setenv "$key" "$value"; }
ask DASHBOARD_URL 'Dashboard URL'; ask DISCORD_BOT_TOKEN 'Discord bot token'; ask DISCORD_CLIENT_ID 'Discord client ID'; ask DISCORD_CLIENT_SECRET 'Discord client secret'; ask DISCORD_GUILD_ID 'Discord guild ID'; ask STAFF_ROLE_IDS 'Staff role IDs (comma-separated)'; ask PTERODACTYL_URL 'Pterodactyl URL'; ask PTERODACTYL_APPLICATION_KEY 'Pterodactyl application API key'; ask PTERODACTYL_CLIENT_KEY 'Pterodactyl client API key';
DBPASS=$(grep '^POSTGRES_PASSWORD=' .env|cut -d= -f2-); sed -i "s#POSTGRES_PASSWORD:.*#POSTGRES_PASSWORD: ${DBPASS}#" docker-compose.yml
# database is initialized from the schema on first startup
sudo docker compose up -d db
sleep 5
sudo docker compose exec -T db psql -U atxcloud -d atxcloud < prisma/schema.sql
sudo docker compose up -d --build
cat <<MSG

AtxCloud control plane is running.
Web: ${DASHBOARD_URL:-http://127.0.0.1:3000}
API: http://127.0.0.1:4000

For Cloudflare Tunnel, route your dashboard hostname to 127.0.0.1:3000.
Keep the existing panel and Wings routes unchanged.
MSG
