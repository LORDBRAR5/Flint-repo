export type ServerStatus='online'|'offline'|'installing'|'maintenance'|'suspended'|'unknown';
export type ServerKind='code'|'minecraft';
export type ServerView={publicId:string;name:string;software:string;version:string;status:ServerStatus;ramUsed:number;ramMax:number;cpuUsed:number;cpuMax:number;diskUsed:number;diskMax:number;backupsUsed:number;backupsMax:number;ownerDiscordId:string};
export const statusLabel=(s:string)=>s.charAt(0).toUpperCase()+s.slice(1);
