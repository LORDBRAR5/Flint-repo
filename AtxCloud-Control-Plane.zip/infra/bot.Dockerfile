FROM node:22-alpine AS build
WORKDIR /app
COPY package.json ./
COPY apps/bot/package.json apps/bot/package.json
RUN npm install
COPY . .
RUN npm run build:bot
FROM node:22-alpine
WORKDIR /app
COPY --from=build /app /app
CMD ["npm","run","bot"]
