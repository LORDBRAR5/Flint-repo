FROM node:22-alpine AS build
WORKDIR /app
COPY package.json ./
COPY apps/api/package.json apps/api/package.json
RUN npm install
COPY . .
RUN npm run build:api
FROM node:22-alpine
WORKDIR /app
COPY --from=build /app /app
CMD ["npm","run","api"]
