FROM node:22-alpine AS build
WORKDIR /app
COPY package.json ./
COPY apps/web/package.json apps/web/package.json
RUN npm install
COPY . .
RUN npm run build:web
FROM node:22-alpine
WORKDIR /app
COPY --from=build /app /app
CMD ["npm","run","web"]
