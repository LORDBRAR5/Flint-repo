CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), discord_id text UNIQUE NOT NULL, username text NOT NULL,
 email text, display_name text, pterodactyl_user_id integer UNIQUE, coins bigint NOT NULL DEFAULT 0,
 coins_earned bigint NOT NULL DEFAULT 0, coins_used bigint NOT NULL DEFAULT 0, blacklisted boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS servers(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), public_id text UNIQUE NOT NULL, pterodactyl_id uuid UNIQUE,
 owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE, name text NOT NULL, egg_id integer,
 nest_id integer, software text, version text, node_id integer, kind text NOT NULL CHECK(kind IN ('code','minecraft')),
 status text NOT NULL DEFAULT 'offline', suspended boolean NOT NULL DEFAULT false, deleted_at timestamptz,
 created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS server_access(
 server_id uuid NOT NULL REFERENCES servers(id) ON DELETE CASCADE, user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 granted_by uuid NOT NULL REFERENCES users(id), created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(server_id,user_id)
);
CREATE TABLE IF NOT EXISTS coin_transactions(
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(), idempotency_key text UNIQUE NOT NULL, from_user_id uuid REFERENCES users(id),
 to_user_id uuid REFERENCES users(id), amount bigint NOT NULL CHECK(amount>0), type text NOT NULL, metadata jsonb NOT NULL DEFAULT '{}',
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS audit_logs(
 id bigserial PRIMARY KEY, actor_discord_id text NOT NULL, action text NOT NULL, target_type text, target_id text,
 metadata jsonb NOT NULL DEFAULT '{}', created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS settings(key text PRIMARY KEY, value jsonb NOT NULL);
CREATE TABLE IF NOT EXISTS nodes(id integer PRIMARY KEY, name text NOT NULL, kind text NOT NULL, enabled boolean NOT NULL DEFAULT true, slot_total integer NOT NULL DEFAULT 0, policy jsonb NOT NULL DEFAULT '{}');
CREATE INDEX IF NOT EXISTS idx_servers_owner ON servers(owner_id) WHERE deleted_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_access_user ON server_access(user_id);
