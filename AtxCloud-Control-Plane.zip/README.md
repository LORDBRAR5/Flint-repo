# AtxCloud Control Plane

Production-oriented control plane for AtxCloud: Discord management bot, API, PostgreSQL state, Pterodactyl adapter, and responsive menu-driven dashboard.

## Discord commands

Public user commands:
- `/manage-server`
- `/my-account`
- `/gift-coins user coins`
- `/share-access server-id user`
- `/remove-access server-id user`

Staff commands:
- `/staff-accounts`
- `/staff-servers`
- `/staff-manage-user user`
- `/staff-manage-server server-id`
- `/staff-purge-servers`
- `/staff-stats`

User command responses are public by design. Every interactive component carries the initiating Discord user ID and is rejected for other users. Server operations are additionally re-authorized server-side against ownership/access records.

## Install

```bash
cp .env.example .env
./scripts/install.sh
```

The installer asks for the Discord/Pterodactyl/dashboard configuration and generates long random internal/cookie/database secrets. It never prints secrets back after entry.

## Cloudflare

Point `dash.atxcloud.ggff.net` at `http://127.0.0.1:3000`. Do not change the existing `panel.atxcloud.ggff.net -> :80` or `node-1.atxcloud.ggff.net -> :8080` routes.

## Important integration notes

The control plane is deliberately server-side: Pterodactyl keys are never shipped to the browser. Provider/economy features belong in the dashboard, not Discord.

Before production use, populate the database's server records from the real Pterodactyl environment and configure the dashboard provisioning policy. The bot will refuse a server action when a client key or server identifier is unavailable rather than reporting a fake success.
