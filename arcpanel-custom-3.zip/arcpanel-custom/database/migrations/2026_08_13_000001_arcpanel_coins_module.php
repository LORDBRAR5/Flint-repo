<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// ArcPanel addon: coins economy. Additive only - does not touch existing
// Pterodactyl tables/columns beyond adding a `coins` column to users.
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->integer('coins')->default(0)->after('root_admin');
            // Populated once Discord/Google OAuth login is wired in (see README —
            // this migration adds the columns now so the coins webhook has
            // somewhere to match against, but the actual OAuth login flow
            // itself is not implemented yet).
            $table->string('discord_id')->nullable()->unique()->after('coins');
            $table->string('google_id')->nullable()->unique()->after('discord_id');
        });

        Schema::create('arc_coin_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->integer('amount');
            $table->string('source'); // afk, discord_join, linktask, purchase:*
            $table->timestamps();
        });

        Schema::create('arc_store_items', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->string('name');
            $table->text('description')->nullable();
            $table->integer('cost');
            // What the purchase does: bump_memory, bump_disk, unlock_slot
            $table->string('effect_type')->nullable();
            $table->integer('effect_amount')->nullable();
            $table->boolean('enabled')->default(true);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('arc_store_items');
        Schema::dropIfExists('arc_coin_transactions');
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('coins');
        });
    }
};
