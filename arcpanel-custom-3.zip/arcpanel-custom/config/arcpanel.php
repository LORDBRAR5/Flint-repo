<?php

return [
    'coins' => [
        'afk_reward_per_minute' => env('ARC_COINS_AFK_PER_MINUTE', 2),
        'discord_join_reward' => env('ARC_COINS_DISCORD_JOIN', 50),
        'discord_webhook_secret' => env('ARC_DISCORD_WEBHOOK_SECRET'),
        'link_task_reward' => env('ARC_COINS_LINK_TASK_REWARD', 15),
        // Your link-shortener base URL with a {destination} placeholder, e.g.
        // https://link-to.net/123456/{destination}. Leave null to skip the shortener.
        'linkvertise_base' => env('ARC_LINKVERTISE_BASE_URL'),
    ],
];
