const colors = require('tailwindcss/colors');

const gray = {
    50: 'hsl(0, 0%, 97%)',
    100: 'hsl(0, 10%, 91%)',
    200: 'hsl(0, 12%, 78%)',
    300: 'hsl(0, 8%, 58%)',
    400: 'hsl(0, 6%, 42%)',
    500: 'hsl(0, 8%, 30%)',
    600: 'hsl(0, 15%, 20%)',
    700: 'hsl(0, 25%, 13%)',
    800: 'hsl(0, 40%, 8%)',
    900: 'hsl(0, 60%, 4%)',
};

const arcRed = {
    50: '#fff1f1',
    100: '#ffdddd',
    200: '#ffb3b3',
    300: '#ff7d7d',
    400: '#ff4040',
    500: '#ff2b2b',
    600: '#e00000',
    700: '#b30000',
    800: '#800000',
    900: '#4d0000',
};

module.exports = {
    content: [
        './resources/scripts/**/*.{js,ts,tsx}',
    ],
    theme: {
        extend: {
            fontFamily: {
                header: ['"IBM Plex Sans"', '"Roboto"', 'system-ui', 'sans-serif'],
            },
            colors: {
                black: '#0a0000',
                // ArcPanel default theme: red & black. "primary" now maps to arcRed instead
                // of Pterodactyl's stock blue. Swap this back to colors.blue to restore
                // the original look, or point it at a different palette for another theme.
                primary: arcRed,
                gray: gray,
                neutral: gray,
                cyan: colors.cyan,
                arc: arcRed,
            },
            fontSize: {
                '2xs': '0.625rem',
            },
            transitionDuration: {
                250: '250ms',
            },
            borderColor: theme => ({
                default: theme('colors.neutral.400', 'currentColor'),
            }),
            backdropBlur: {
                glass: '18px',
            },
            boxShadow: {
                glow: '0 0 20px rgba(255, 43, 43, 0.45)',
            },
        },
    },
    plugins: [
        require('@tailwindcss/line-clamp'),
        require('@tailwindcss/forms')({
            strategy: 'class',
        }),
    ]
};
