<?php

namespace Pterodactyl\Models;

class ArcStoreItem extends Model
{
    protected $table = 'arc_store_items';
    protected $fillable = ['key', 'name', 'description', 'cost', 'effect_type', 'effect_amount', 'enabled'];
}
