<?php

namespace Pterodactyl\Models;

class ArcCoinTransaction extends Model
{
    protected $table = 'arc_coin_transactions';
    protected $fillable = ['user_id', 'amount', 'source'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
